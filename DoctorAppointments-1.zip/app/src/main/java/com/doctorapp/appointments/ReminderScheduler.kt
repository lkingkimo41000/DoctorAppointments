package com.doctorapp.appointments

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.*

/**
 * يجدول التنبيهات الثلاثة لكل موعد طبي مبرمج مسبقاً:
 * قبل 48 ساعة، قبل 24 ساعة، وفي يوم الموعد (صباحاً).
 * يستخدم AlarmManager لإرسالها حتى لو كان التطبيق مغلقاً.
 */
object ReminderScheduler {

    const val TYPE_48H = "48h"
    const val TYPE_24H = "24h"
    const val TYPE_TODAY = "today"

    private const val HOUR_MS = 60 * 60 * 1000L

    fun scheduleAllReminders(context: Context, appointment: Appointment) {
        val apptDate = parseDateTime(appointment.appointmentDate) ?: return
        val now = Calendar.getInstance()

        // قبل 48 ساعة
        val time48 = apptDate.clone() as Calendar
        time48.add(Calendar.HOUR_OF_DAY, -48)
        if (time48.after(now) && !appointment.notified48) {
            scheduleOne(context, appointment.id, TYPE_48H, time48.timeInMillis)
        }

        // قبل 24 ساعة
        val time24 = apptDate.clone() as Calendar
        time24.add(Calendar.HOUR_OF_DAY, -24)
        if (time24.after(now) && !appointment.notified24) {
            scheduleOne(context, appointment.id, TYPE_24H, time24.timeInMillis)
        }

        // في يوم الموعد، ساعة 8 صباحاً (أو فوراً إن كان الوقت قد فات لكن الموعد اليوم)
        val timeToday = apptDate.clone() as Calendar
        timeToday.set(Calendar.HOUR_OF_DAY, 8)
        timeToday.set(Calendar.MINUTE, 0)
        if (timeToday.before(now)) {
            timeToday.timeInMillis = now.timeInMillis + 60_000L
        }
        if (!appointment.notifiedToday) {
            scheduleOne(context, appointment.id, TYPE_TODAY, timeToday.timeInMillis)
        }
    }

    fun cancelAllReminders(context: Context, appointmentId: Long) {
        cancelOne(context, appointmentId, TYPE_48H)
        cancelOne(context, appointmentId, TYPE_24H)
        cancelOne(context, appointmentId, TYPE_TODAY)
    }

    private fun scheduleOne(context: Context, appointmentId: Long, type: String, triggerAtMillis: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = buildPendingIntent(context, appointmentId, type)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
        } catch (e: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }

    private fun cancelOne(context: Context, appointmentId: Long, type: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(buildPendingIntent(context, appointmentId, type))
    }

    private fun buildPendingIntent(context: Context, appointmentId: Long, type: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_APPOINTMENT_ID, appointmentId)
            putExtra(ReminderReceiver.EXTRA_TYPE, type)
        }
        val requestCode = ("$appointmentId-$type").hashCode()
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun parseDateTime(value: String?): Calendar? {
        if (value.isNullOrBlank()) return null
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            val date = format.parse(value) ?: return null
            Calendar.getInstance().apply { time = date }
        } catch (e: Exception) {
            null
        }
    }
}
