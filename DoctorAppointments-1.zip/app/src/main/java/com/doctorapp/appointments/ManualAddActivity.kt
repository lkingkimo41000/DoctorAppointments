package com.doctorapp.appointments

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class ManualAddActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual_add)

        val etName = findViewById<EditText>(R.id.etPatientName)
        val etPhone = findViewById<EditText>(R.id.etPatientPhone)
        val etNote = findViewById<EditText>(R.id.etNote)

        findViewById<MaterialButton>(R.id.btnSaveManual).setOnClickListener {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val note = etNote.text.toString().trim()

            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "يرجى إدخال اسم المريض ورقم الهاتف", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val db = DatabaseHelper(this)
            db.insertManualAppointment(phone, name, note)
            Toast.makeText(this, "تم إضافة الموعد يدوياً", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
