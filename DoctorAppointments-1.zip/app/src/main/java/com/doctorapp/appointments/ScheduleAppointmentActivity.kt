package com.doctorapp.appointments

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.util.*

class ScheduleAppointmentActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var allPatients: List<DatabaseHelper.PatientRef> = emptyList()
    private var selectedPatient: DatabaseHelper.PatientRef? = null

    private var selectedYear = -1
    private var selectedMonth = -1
    private var selectedDay = -1
    private var selectedHour = -1
    private var selectedMinute = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule)
        db = DatabaseHelper(this)
        allPatients = db.getDistinctPatients()

        val tvSelected = findViewById<TextView>(R.id.tvSelectedPatient)
        val recycler = findViewById<RecyclerView>(R.id.recyclerPatients)
        recycler.layoutManager = LinearLayoutManager(this)

        val adapter = PatientAdapter(allPatients) { patient ->
            selectedPatient = patient
            tvSelected.text = "المريض المختار: ${patient.name} — ${patient.phone}"
        }
        recycler.adapter = adapter

        findViewById<EditText>(R.id.etPatientSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim().orEmpty()
                val filtered = if (query.isEmpty()) allPatients else allPatients.filter {
                    it.name.contains(query, ignoreCase = true) || it.phone.contains(query)
                }
                adapter.updateData(filtered)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val tvChosenDateTime = findViewById<TextView>(R.id.tvChosenDateTime)

        findViewById<MaterialButton>(R.id.btnPickDate).setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, day ->
                selectedYear = year; selectedMonth = month; selectedDay = day
                updateChosenDateTimeLabel(tvChosenDateTime)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        findViewById<MaterialButton>(R.id.btnPickTime).setOnClickListener {
            val cal = Calendar.getInstance()
            TimePickerDialog(this, { _, hour, minute ->
                selectedHour = hour; selectedMinute = minute
                updateChosenDateTimeLabel(tvChosenDateTime)
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }

        findViewById<MaterialButton>(R.id.btnSaveSchedule).setOnClickListener {
            val patient = selectedPatient
            if (patient == null) {
                Toast.makeText(this, "يرجى اختيار مريض من القائمة أولاً", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (selectedYear < 0 || selectedHour < 0) {
                Toast.makeText(this, "يرجى اختيار تاريخ ووقت الموعد", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val cal = Calendar.getInstance()
            cal.set(selectedYear, selectedMonth, selectedDay, selectedHour, selectedMinute)
            val dateTimeStr = DatabaseHelper.DATETIME_FORMAT.format(cal.time)

            val id = db.insertScheduledAppointment(patient.phone, patient.name, dateTimeStr)
            val appointment = db.getAppointmentById(id)
            if (appointment != null) {
                ReminderScheduler.scheduleAllReminders(this, appointment)
            }
            Toast.makeText(this, "تم برمجة الموعد وجدولة رسائل التذكير", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun updateChosenDateTimeLabel(label: TextView) {
        if (selectedYear < 0 || selectedHour < 0) return
        val cal = Calendar.getInstance()
        cal.set(selectedYear, selectedMonth, selectedDay, selectedHour, selectedMinute)
        label.text = "📅 الموعد المحدد: ${DatabaseHelper.DATETIME_FORMAT.format(cal.time)}"
    }

    private class PatientAdapter(
        private var items: List<DatabaseHelper.PatientRef>,
        private val onSelect: (DatabaseHelper.PatientRef) -> Unit
    ) : RecyclerView.Adapter<PatientAdapter.VH>() {

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            val name: TextView = view.findViewById(R.id.tvPatientName)
            val phone: TextView = view.findViewById(R.id.tvPatientPhone)
        }

        override fun onCreateViewHolder(parent: ViewGroup, position: Int): VH {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_patient, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.name.text = item.name
            holder.phone.text = item.phone
            holder.itemView.setOnClickListener { onSelect(item) }
        }

        override fun getItemCount(): Int = items.size

        fun updateData(newItems: List<DatabaseHelper.PatientRef>) {
            items = newItems
            notifyDataSetChanged()
        }
    }
}
