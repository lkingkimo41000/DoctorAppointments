package com.doctorapp.appointments

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * إشعارات دخول موعد جديد (تصل تلقائياً عبر رسالة SMS من المريض).
 *
 * قناة الإشعار على أندرويد 8+ تُبقى صامتة من ناحية النظام، والتطبيق هو من
 * يتحكّم بتشغيل الصوت والاهتزاز يدوياً — بهذا يستطيع الطبيب/ة كتم أو تفعيل
 * صوت التنبيه من شاشة الإعدادات مباشرة، بدل الاضطرار لفتح إعدادات النظام
 * (التي تقفل صوت القناة نهائياً على أندرويد 8 فما فوق).
 */
object NotificationHelper {

    private const val CHANNEL_ID = "new_appointment_channel"
    private const val CHANNEL_NAME = "مواعيد جديدة"
    private const val NOTIFICATION_ID_BASE = 5000

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java) ?: return
            if (manager.getNotificationChannel(CHANNEL_ID) != null) return

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار فوري عند دخول موعد جديد لمريض"
                setSound(null, null) // الصوت يُشغَّل يدوياً من التطبيق حتى يعمل الكتم/التفعيل
                enableVibration(false) // الاهتزاز أيضاً يدوي لنفس السبب
                enableLights(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * يعرض إشعاراً بدخول موعد جديد، ويشغّل صوت واهتزاز على طريقة إشعارات
     * الرسائل الفورية (ماسنجر) إن كان الصوت مفعّلاً في الإعدادات.
     */
    fun showNewAppointmentNotification(
        context: Context,
        patientName: String,
        phone: String,
        statusLabel: String
    ) {
        createChannel(context)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingIntent = PendingIntent.getActivity(context, 0, openIntent, pendingIntentFlags)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("📅 موعد جديد")
            .setContentText("$patientName ($phone) — $statusLabel")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("تم تسجيل موعد جديد للمريض $patientName\nالحالة: $statusLabel")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = NOTIFICATION_ID_BASE + (System.currentTimeMillis() % 10000).toInt()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // لم يُمنح إذن الإشعارات على أندرويد 13+ — نتجاهل بأمان دون تعطيل باقي التطبيق
        }

        if (Prefs.isNotificationSoundEnabled(context)) {
            playMessengerStyleAlert(context)
        }
    }

    private fun playMessengerStyleAlert(context: Context) {
        try {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(context, soundUri)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ringtone?.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            }
            ringtone?.play()
        } catch (_: Exception) {
            // تجاهل أي خطأ في تشغيل الصوت (مثلاً عدم توفر نغمة افتراضية)
        }

        vibrateMessengerStyle(context)
    }

    /** نمط اهتزاز قصير مزدوج، يشبه اهتزاز إشعارات الرسائل الفورية */
    private fun vibrateMessengerStyle(context: Context) {
        try {
            val pattern = longArrayOf(0, 120, 80, 120)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(VibratorManager::class.java)
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (_: Exception) {
            // تجاهل أي خطأ في الاهتزاز (مثلاً جهاز بدون محرك اهتزاز)
        }
    }
}
