package com.doctorapp.appointments

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * تُعاد جدولة كل تنبيهات المواعيد المبرمجة (48س / 24س / يوم الموعد) التي لم تُرسَل بعد
 * عند إعادة تشغيل الهاتف، لأن AlarmManager يفقد كل التنبيهات المجدولة بعد إعادة التشغيل.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val db = DatabaseHelper(context)
        val upcoming = db.getUpcomingScheduledAppointments()
        upcoming.forEach { appointment ->
            ReminderScheduler.scheduleAllReminders(context, appointment)
        }
    }
}
