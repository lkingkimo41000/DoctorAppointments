package com.doctorapp.appointments

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * نظام التفعيل عن بعد.
 *
 * الفكرة: أنت (المطوّر) تملك قاعدة بيانات Firebase Realtime Database مجانية.
 * بداخلها عقدة "licenses" وتحتها كود لكل زبونة (طبيبة)، مثلاً:
 *
 *   licenses/
 *     AHM-2026-001/
 *         active: true
 *         durationDays: 30
 *         usedBy: null
 *         activatedAt: null
 *         expiresAt: null
 *         note: "د. سارة - عيادة الأطفال"
 *
 * أنت من يُنشئ هذه الأكواد ويحدد مدة كل كود (durationDays)، ومن يستطيع
 * إيقاف أي كود في أي وقت بتغيير active إلى false مباشرة من لوحة تحكم
 * Firebase (بدون الحاجة لأي تطبيق إضافي). التطبيق نفسه لا يملك أي صلاحية
 * لإنشاء أو حذف الأكواد؛ فقط للتحقق منها وتفعيلها أول مرة.
 *
 * عند إدخال الطبيبة للكود أول مرة: يربط التطبيق الكود بجهازها (usedBy)
 * ويحسب تاريخ الانتهاء (الآن + durationDays) ويخزّنه في نفس عقدة الكود على
 * الخادم، حتى لو غيّرت الطبيبة توقيت هاتفها لا يستطيع أحد "تمديد" الكود
 * محلياً لأن مصدر الحقيقة هو الخادم.
 *
 * ⚠️ قبل الاستخدام يجب استبدال FIREBASE_DB_URL أدناه برابط قاعدة بياناتك
 * الحقيقية (راجع التعليمات المرفقة لإنشائها مجاناً خلال دقائق).
 */
object LicenseManager {

    // ضع هنا رابط قاعدة بيانات Firebase Realtime Database الخاصة بك
    // مثال: "https://doctor-app-licenses-default-rtdb.europe-west1.firebasedatabase.app/"
    private const val FIREBASE_DB_URL = "https://maw3id-fa26b-default-rtdb.europe-west1.firebasedatabase.app/"

    // مدة صلاحية النسخة المحلية المخزنة بدون اتصال بالإنترنت (أيام سماح)
    // بعدها يُطلب من التطبيق التحقق من الخادم مجدداً قبل الاستمرار
    private const val OFFLINE_GRACE_PERIOD_MS = 5L * 24 * 60 * 60 * 1000 // 5 أيام

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    data class LicenseResult(val success: Boolean, val message: String)

    /** معرّف ثابت لهذا الجهاز، يُستخدم لربط الكود بجهاز واحد فقط */
    fun deviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"

    /**
     * فحص سريع محلي (بدون إنترنت) يحدد هل التطبيق مسموح بالعمل الآن أم لا.
     * يُستخدم عند كل فتح للتطبيق قبل عرض أي شاشة.
     */
    fun isLicenseValidLocally(context: Context): Boolean {
        val code = Prefs.getLicenseCode(context)
        if (code.isBlank()) return false

        val active = Prefs.isLicenseActiveFlag(context)
        val expiresAt = Prefs.getLicenseExpiresAt(context)
        val lastSync = Prefs.getLicenseLastSync(context)
        val now = System.currentTimeMillis()

        if (!active) return false
        if (now >= expiresAt) return false
        // إن مرّت فترة السماح بدون أي تحقق ناجح من الخادم، نطلب تحققاً جديداً
        if (now - lastSync > OFFLINE_GRACE_PERIOD_MS) return false

        return true
    }

    /** تفعيل التطبيق أول مرة بإدخال الكود */
    fun activate(context: Context, rawCode: String, callback: (LicenseResult) -> Unit) {
        val code = rawCode.trim().uppercase()
        if (code.isBlank()) {
            callback(LicenseResult(false, "الرجاء إدخال كود التفعيل"))
            return
        }
        executor.execute {
            try {
                val json = httpGet("licenses/$code.json")
                if (json == null || json == JSONObject.NULL.toString() || json == "null") {
                    postResult(callback, LicenseResult(false, "كود التفعيل غير صحيح"))
                    return@execute
                }
                val obj = JSONObject(json)
                val active = obj.optBoolean("active", false)
                if (!active) {
                    postResult(callback, LicenseResult(false, "هذا الكود موقوف حالياً، يرجى التواصل مع المطوّر"))
                    return@execute
                }

                val usedBy = if (obj.isNull("usedBy")) null else obj.optString("usedBy", null)
                val myDeviceId = deviceId(context)
                val now = System.currentTimeMillis()

                var expiresAt: Long
                if (usedBy.isNullOrBlank()) {
                    // أول تفعيل لهذا الكود: نربطه بهذا الجهاز ونحسب تاريخ الانتهاء
                    val durationDays = obj.optInt("durationDays", 30)
                    expiresAt = now + durationDays * 24L * 60 * 60 * 1000

                    val patchBody = JSONObject()
                        .put("usedBy", myDeviceId)
                        .put("activatedAt", now)
                        .put("expiresAt", expiresAt)
                    httpPatch("licenses/$code.json", patchBody)
                } else if (usedBy != myDeviceId) {
                    postResult(callback, LicenseResult(false, "هذا الكود مُفعَّل مسبقاً على جهاز آخر"))
                    return@execute
                } else {
                    // إعادة تفعيل على نفس الجهاز (مثلاً بعد حذف التطبيق وإعادة تثبيته)
                    expiresAt = obj.optLong("expiresAt", now)
                }

                if (now >= expiresAt) {
                    Prefs.saveLicenseState(context, code, false, expiresAt, now)
                    postResult(callback, LicenseResult(false, "انتهت صلاحية هذا الكود، يرجى التواصل مع المطوّر لكود جديد"))
                    return@execute
                }

                Prefs.saveLicenseState(context, code, true, expiresAt, now)
                postResult(callback, LicenseResult(true, "تم التفعيل بنجاح"))
            } catch (e: Exception) {
                postResult(callback, LicenseResult(false, "تعذّر الاتصال بخادم التفعيل، تحقّقي من الإنترنت وحاولي مجدداً"))
            }
        }
    }

    /**
     * إعادة التحقق من صلاحية الكود من الخادم (يُستدعى دورياً أثناء استخدام
     * التطبيق حتى تنعكس أي عملية إلغاء أو تغيير مدة يقوم بها المطوّر مباشرة).
     * لا تُغلق التطبيق إن فشل الاتصال بالإنترنت فقط — تعتمد عندها على آخر
     * نسخة محفوظة محلياً ضمن فترة السماح.
     */
    fun revalidate(context: Context, callback: ((Boolean) -> Unit)? = null) {
        val code = Prefs.getLicenseCode(context)
        if (code.isBlank()) {
            callback?.let { postResult(it, false) }
            return
        }
        executor.execute {
            try {
                val json = httpGet("licenses/$code.json")
                val now = System.currentTimeMillis()
                if (json == null || json == "null") {
                    Prefs.saveLicenseState(context, code, false, 0L, now)
                    callback?.let { postResult(it, false) }
                    return@execute
                }
                val obj = JSONObject(json)
                val active = obj.optBoolean("active", false)
                val expiresAt = obj.optLong("expiresAt", 0L)
                Prefs.saveLicenseState(context, code, active, expiresAt, now)
                callback?.let { postResult(it, active && now < expiresAt) }
            } catch (e: Exception) {
                // لا اتصال: نكتفي بالفحص المحلي (فترة السماح)
                callback?.let { postResult(it, isLicenseValidLocally(context)) }
            }
        }
    }

    // ============ أدوات HTTP داخلية ============

    private fun httpGet(path: String): String? {
        val url = URL(FIREBASE_DB_URL.trimEnd('/') + "/" + path)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        return try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) return null
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun httpPatch(path: String, body: JSONObject) {
        val url = URL(FIREBASE_DB_URL.trimEnd('/') + "/" + path)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "PATCH"
        conn.doOutput = true
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("Content-Type", "application/json")
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            conn.responseCode // لتنفيذ الطلب فعلياً
        } finally {
            conn.disconnect()
        }
    }

    private fun postResult(callback: (LicenseResult) -> Unit, result: LicenseResult) {
        mainHandler.post { callback(result) }
    }

    private fun postResult(callback: (Boolean) -> Unit, result: Boolean) {
        mainHandler.post { callback(result) }
    }
}
