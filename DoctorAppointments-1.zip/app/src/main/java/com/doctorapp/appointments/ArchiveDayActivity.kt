package com.doctorapp.appointments

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ArchiveDayActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DAY_KEY = "day_key"
    }

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: AppointmentAdapter
    private lateinit var dayKey: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appointment_list)
        db = DatabaseHelper(this)
        dayKey = intent.getStringExtra(EXTRA_DAY_KEY) ?: DatabaseHelper.todayKey()

        findViewById<TextView>(R.id.tvHeaderTitle).text = "📅 مواعيد يوم $dayKey"

        val recycler = findViewById<RecyclerView>(R.id.recyclerList)
        recycler.layoutManager = LinearLayoutManager(this)

        val items = db.getAppointmentsForDay(dayKey)
        findViewById<TextView>(R.id.tvEmptyList).visibility =
            if (items.isEmpty()) View.VISIBLE else View.GONE

        adapter = AppointmentAdapter(
            items = items,
            onDeleteRequest = { appointment ->
                AppUtils.requestDeletePassword(this) {
                    db.deleteAppointment(appointment.id)
                    refresh()
                }
            },
            onCall = { AppUtils.callPatient(this, it.phone) },
            onAccept = {}, onMoveFromReserve = {}, onAbsent = {},
            onEnterDoctor = {}, onFinish = {}, onRestore = {},
            readOnly = true
        )
        recycler.adapter = adapter
    }

    private fun refresh() {
        val items = db.getAppointmentsForDay(dayKey)
        adapter.updateData(items)
        findViewById<TextView>(R.id.tvEmptyList).visibility =
            if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
