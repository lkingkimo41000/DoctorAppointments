package com.doctorapp.appointments

import android.content.Context
import android.net.Uri
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * تصدير واستيراد قاعدة بيانات المواعيد كملف واحد محمي بكلمة سر يختارها
 * الطبيب/ة عند التصدير. الملف كاملاً مشفّر (AES-256/GCM) بمفتاح مُشتق من
 * كلمة السر عبر PBKDF2، لذلك لا يمكن فتح أو استرجاع النسخة الاحتياطية
 * بدون معرفة كلمة السر نفسها، حتى لو وصل الملف لشخص آخر.
 */
object BackupManager {

    // ترويسة تعريفية للتأكد أن الملف المستورد هو نسخة احتياطية صادرة من هذا التطبيق
    private val MAGIC = byteArrayOf('D'.code.toByte(), 'A'.code.toByte(), 'B'.code.toByte(), '1'.code.toByte())
    private const val SALT_SIZE = 16
    private const val IV_SIZE = 12
    private const val GCM_TAG_BITS = 128
    private const val PBKDF2_ITERATIONS = 120_000
    private const val KEY_LENGTH_BITS = 256
    private val SQLITE_HEADER = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)

    /** تُرمى عند فشل فك التشفير (كلمة سر خاطئة أو ملف غير صالح/تالف) */
    class WrongPasswordException : Exception("كلمة السر غير صحيحة، أو الملف غير صالح")

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, KEY_LENGTH_BITS)
        val keyBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, "AES")
    }

    /**
     * يقرأ ملف قاعدة البيانات الحالي، يشفّره بكلمة السر المُعطاة، ويكتبه
     * إلى الـ Uri الذي اختاره المستخدم (عبر منتقي حفظ الملفات في النظام).
     */
    fun exportEncrypted(context: Context, destinationUri: Uri, password: String) {
        val dbFile = context.getDatabasePath(DatabaseHelper.DB_NAME)
        if (!dbFile.exists()) {
            throw IllegalStateException("لا توجد قاعدة بيانات لتصديرها بعد")
        }

        val rawBytes = dbFile.readBytes()

        val random = SecureRandom()
        val salt = ByteArray(SALT_SIZE).also { random.nextBytes(it) }
        val iv = ByteArray(IV_SIZE).also { random.nextBytes(it) }

        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        val encrypted = cipher.doFinal(rawBytes)

        val out = context.contentResolver.openOutputStream(destinationUri)
            ?: throw IllegalStateException("تعذّر إنشاء ملف النسخة الاحتياطية")
        out.use {
            it.write(MAGIC)
            it.write(salt)
            it.write(iv)
            it.write(encrypted)
        }
    }

    /**
     * يقرأ ملف نسخة احتياطية مشفّرة، يفكّ تشفيره بكلمة السر المُعطاة، يتحقق
     * أنه قاعدة بيانات SQLite صالحة، ثم يستبدل قاعدة البيانات الحالية بها.
     * يجب إعادة تشغيل التطبيق بعد نجاح الاستيراد لضمان قراءة البيانات الجديدة.
     */
    fun importEncrypted(context: Context, sourceUri: Uri, password: String) {
        val bytes = context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
            ?: throw IllegalStateException("تعذّر قراءة الملف المحدد")

        val minSize = MAGIC.size + SALT_SIZE + IV_SIZE + 1
        if (bytes.size < minSize) throw WrongPasswordException()

        var offset = 0
        val magic = bytes.copyOfRange(offset, MAGIC.size); offset += MAGIC.size
        if (!magic.contentEquals(MAGIC)) throw WrongPasswordException()

        val salt = bytes.copyOfRange(offset, offset + SALT_SIZE); offset += SALT_SIZE
        val iv = bytes.copyOfRange(offset, offset + IV_SIZE); offset += IV_SIZE
        val cipherText = bytes.copyOfRange(offset, bytes.size)

        val key = deriveKey(password, salt)
        val decrypted: ByteArray
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            decrypted = cipher.doFinal(cipherText)
        } catch (e: Exception) {
            throw WrongPasswordException()
        }

        if (decrypted.size < SQLITE_HEADER.size ||
            !decrypted.copyOfRange(0, SQLITE_HEADER.size).contentEquals(SQLITE_HEADER)
        ) {
            throw WrongPasswordException()
        }

        val dbFile = context.getDatabasePath(DatabaseHelper.DB_NAME)
        // حذف قاعدة البيانات الحالية (وملفات journal/wal المرتبطة بها) قبل الاستبدال
        context.deleteDatabase(DatabaseHelper.DB_NAME)
        dbFile.parentFile?.mkdirs()
        dbFile.writeBytes(decrypted)
    }
}
