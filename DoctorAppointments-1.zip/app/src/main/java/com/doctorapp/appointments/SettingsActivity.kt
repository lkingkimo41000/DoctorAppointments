package com.doctorapp.appointments

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val etPhone = findViewById<EditText>(R.id.etDoctorPhone)
        val etNewPin = findViewById<EditText>(R.id.etNewPin)
        val etNewDeletePassword = findViewById<EditText>(R.id.etNewDeletePassword)
        val switchRegistration = findViewById<SwitchMaterial>(R.id.switchRegistration)
        val etCurrentPin = findViewById<EditText>(R.id.etCurrentPin)

        etPhone.setText(Prefs.getDoctorPhone(this))
        switchRegistration.isChecked = Prefs.isRegistrationOpen(this)

        findViewById<MaterialButton>(R.id.btnSaveSettings).setOnClickListener {
            val currentPin = etCurrentPin.text.toString().trim()
            if (!Prefs.checkPin(this, currentPin)) {
                Toast.makeText(this, "كلمة سر الفتح الحالية غير صحيحة", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newPhone = etPhone.text.toString().trim()
            if (newPhone.length >= 6) {
                Prefs.setDoctorPhone(this, newPhone)
            }

            val newPin = etNewPin.text.toString().trim()
            if (newPin.isNotEmpty()) {
                if (newPin.length < 4) {
                    Toast.makeText(this, "كلمة السر الجديدة يجب أن تكون 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                Prefs.setPin(this, newPin)
            }

            val newDeletePassword = etNewDeletePassword.text.toString().trim()
            if (newDeletePassword.isNotEmpty()) {
                if (newDeletePassword.length < 4) {
                    Toast.makeText(this, "كلمة سر الحذف الجديدة يجب أن تكون 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                Prefs.setDeletePassword(this, newDeletePassword)
            }

            Prefs.setRegistrationOpen(this, switchRegistration.isChecked)

            Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
