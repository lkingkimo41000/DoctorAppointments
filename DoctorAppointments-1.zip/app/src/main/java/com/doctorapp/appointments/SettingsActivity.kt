package com.doctorapp.appointments

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private var pendingExportPassword: String? = null
    private var pendingImportUri: Uri? = null

    companion object {
        private const val REQUEST_CODE_EXPORT = 201
        private const val REQUEST_CODE_IMPORT = 202
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val etPhone = findViewById<EditText>(R.id.etDoctorPhone)
        val etNewPin = findViewById<EditText>(R.id.etNewPin)
        val etNewDeletePassword = findViewById<EditText>(R.id.etNewDeletePassword)
        val switchRegistration = findViewById<SwitchMaterial>(R.id.switchRegistration)
        val etCurrentPin = findViewById<EditText>(R.id.etCurrentPin)
        val switchNotificationSound = findViewById<SwitchMaterial>(R.id.switchNotificationSound)

        etPhone.setText(Prefs.getDoctorPhone(this))
        switchRegistration.isChecked = Prefs.isRegistrationOpen(this)

        // صوت الإشعارات: يُحفظ فوراً دون الحاجة لكلمة سر (إعداد غير حساس)
        switchNotificationSound.isChecked = Prefs.isNotificationSoundEnabled(this)
        switchNotificationSound.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setNotificationSoundEnabled(this, isChecked)
        }

        findViewById<MaterialButton>(R.id.btnExportDb).setOnClickListener {
            promptNewPasswordThenExport()
        }

        findViewById<MaterialButton>(R.id.btnImportDb).setOnClickListener {
            launchImportPicker()
        }

        findViewById<MaterialButton>(R.id.btnSaveSettings).setOnClickListener {
            val currentPin = etCurrentPin.text.toString().trim()
            if (!Prefs.checkPin(this, currentPin)) {
                Toast.makeText(this, "كلمة سر الفتح الحالية غير صحيحة", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newPhone = etPhone.text.toString().trim()
            if (newPhone.length >= 6) {
                Prefs.setDoctorPhone(this, newPhone)
            }

            val newPin = etNewPin.text.toString().trim()
            if (newPin.isNotEmpty()) {
                if (newPin.length < 4) {
                    Toast.makeText(this, "كلمة السر الجديدة يجب أن تكون 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                Prefs.setPin(this, newPin)
            }

            val newDeletePassword = etNewDeletePassword.text.toString().trim()
            if (newDeletePassword.isNotEmpty()) {
                if (newDeletePassword.length < 4) {
                    Toast.makeText(this, "كلمة سر الحذف الجديدة يجب أن تكون 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                Prefs.setDeletePassword(this, newDeletePassword)
            }

            Prefs.setRegistrationOpen(this, switchRegistration.isChecked)

            Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    // ================= تصدير قاعدة البيانات =================

    /** يطلب من المستخدم اختيار كلمة سر للنسخة الاحتياطية وتأكيدها، ثم يفتح منتقي حفظ الملف */
    private fun promptNewPasswordThenExport() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val etPassword = EditText(this).apply {
            hint = "كلمة سر جديدة لحماية الملف"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val etConfirm = EditText(this).apply {
            hint = "تأكيد كلمة السر"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        container.addView(etPassword)
        container.addView(etConfirm)

        AlertDialog.Builder(this)
            .setTitle("⬆️ تصدير قاعدة البيانات")
            .setMessage("اختر كلمة سر ستُستخدم لتشفير النسخة الاحتياطية. ستحتاج نفس كلمة السر عند الاستيراد لاحقاً.")
            .setView(container)
            .setPositiveButton("متابعة") { _, _ ->
                val pass = etPassword.text.toString()
                val confirm = etConfirm.text.toString()
                if (pass.length < 4) {
                    Toast.makeText(this, "كلمة السر يجب أن تكون 4 أحرف على الأقل", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (pass != confirm) {
                    Toast.makeText(this, "كلمتا السر غير متطابقتين", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                pendingExportPassword = pass
                launchExportPicker()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun launchExportPicker() {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "نسخة_احتياطية_المواعيد_$stamp.dab")
        }
        startActivityForResult(intent, REQUEST_CODE_EXPORT)
    }

    // ================= استيراد قاعدة البيانات =================

    private fun launchImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQUEST_CODE_IMPORT)
    }

    private fun promptPasswordThenImport(uri: Uri) {
        val etPassword = EditText(this).apply {
            hint = "كلمة سر النسخة الاحتياطية"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle("⬇️ استيراد نسخة احتياطية")
            .setMessage("سيتم استبدال كل بيانات المواعيد الحالية بالنسخة المستوردة. أدخل كلمة السر المستخدمة عند التصدير.")
            .setView(etPassword)
            .setPositiveButton("استيراد") { _, _ ->
                performImport(uri, etPassword.text.toString())
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun performImport(uri: Uri, password: String) {
        Toast.makeText(this, "جارٍ الاستيراد...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                BackupManager.importEncrypted(this, uri, password)
                runOnUiThread {
                    Toast.makeText(this, "✅ تم الاستيراد بنجاح. سيُعاد فتح التطبيق الآن.", Toast.LENGTH_LONG).show()
                    restartApp()
                }
            } catch (e: BackupManager.WrongPasswordException) {
                runOnUiThread {
                    Toast.makeText(this, "❌ ${e.message}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "❌ تعذّر الاستيراد: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** إعادة تشغيل التطبيق بالكامل لضمان قراءة قاعدة البيانات المستوردة من الصفر */
    private fun restartApp() {
        val intent = Intent(this, PinLockActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!

        when (requestCode) {
            REQUEST_CODE_EXPORT -> {
                val password = pendingExportPassword
                pendingExportPassword = null
                if (password == null) return
                Toast.makeText(this, "جارٍ التصدير...", Toast.LENGTH_SHORT).show()
                Thread {
                    try {
                        BackupManager.exportEncrypted(this, uri, password)
                        runOnUiThread {
                            Toast.makeText(this, "✅ تم تصدير النسخة الاحتياطية بنجاح", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "❌ تعذّر التصدير: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            REQUEST_CODE_IMPORT -> {
                pendingImportUri = uri
                promptPasswordThenImport(uri)
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
