package com.doctorapp.appointments

import android.content.Context
import android.telephony.SmsManager
import android.util.Log

/**
 * مسؤول عن إرسال كل الرسائل النصية للمرضى من رقم هاتف الطبيبة نفسه (شريحة SIM الجهاز):
 * - رسالة القبول
 * - تنبيه "الموعد بعد 30 دقيقة" للمريض الثالث في الدور
 * - تذكير الموعد المبرمج: قبل 48 ساعة، وقبل 24 ساعة، وفي يوم الموعد
 * - رسالة الشكر والدعاء بالشفاء بعد انتهاء الكشف
 */
object SmsSender {

    fun sendAcceptance(context: Context, phone: String, name: String) {
        send(phone, context.getString(R.string.msg_acceptance, name))
    }

    fun sendThirtyMinuteNotice(context: Context, phone: String, name: String) {
        send(phone, context.getString(R.string.msg_thirty_min, name))
    }

    fun sendReminder48h(context: Context, phone: String, name: String, dateTime: String) {
        send(phone, context.getString(R.string.msg_reminder_48, name, dateTime))
    }

    fun sendReminder24h(context: Context, phone: String, name: String, dateTime: String) {
        send(phone, context.getString(R.string.msg_reminder_24, name, dateTime))
    }

    fun sendReminderToday(context: Context, phone: String, name: String, dateTime: String) {
        send(phone, context.getString(R.string.msg_reminder_today, name, dateTime))
    }

    fun sendThankYou(context: Context, phone: String, name: String) {
        send(phone, context.getString(R.string.msg_thank_you, name))
    }

    private fun send(phone: String, text: String) {
        try {
            val smsManager = SmsManager.getDefault()
            val parts = smsManager.divideMessage(text)
            smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
            Log.i("SmsSender", "تم إرسال رسالة إلى: $phone")
        } catch (e: Exception) {
            Log.e("SmsSender", "فشل إرسال الرسالة إلى: $phone", e)
        }
    }
}
