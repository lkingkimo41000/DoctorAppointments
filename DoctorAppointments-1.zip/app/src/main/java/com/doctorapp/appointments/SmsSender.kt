package com.doctorapp.appointments

import android.content.Context
import android.telephony.SmsManager
import android.util.Log

/**
 * مسؤول عن إرسال الرسائل النصية للمرضى:
 * - رسالة القبول (تُرسل فقط عند ضغط الطبيبة على زر "قبول")
 * - رسالة تنبيه "الموعد بعد 30 دقيقة" (تُرسل عند دخول مريض عند الطبيبة، للمريض الثالث في الدور)
 */
object SmsSender {

    fun sendAcceptance(context: Context, phone: String, name: String) {
        val text = context.getString(R.string.msg_acceptance, name)
        send(phone, text)
    }

    fun sendThirtyMinuteNotice(context: Context, phone: String, name: String) {
        val text = context.getString(R.string.msg_thirty_min, name)
        send(phone, text)
    }

    private fun send(phone: String, text: String) {
        try {
            val smsManager = SmsManager.getDefault()
            val parts = smsManager.divideMessage(text)
            smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
            Log.i("SmsSender", "تم إرسال رسالة إلى: $phone")
        } catch (e: Exception) {
            Log.e("SmsSender", "فشل إرسال الرسالة إلى: $phone", e)
        }
    }
}
