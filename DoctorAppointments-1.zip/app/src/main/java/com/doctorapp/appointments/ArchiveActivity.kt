package com.doctorapp.appointments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ArchiveActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_archive)
        db = DatabaseHelper(this)

        val recycler = findViewById<RecyclerView>(R.id.recyclerDays)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        recycler.layoutManager = LinearLayoutManager(this)

        val days = db.getArchiveDays()
        tvEmpty.visibility = if (days.isEmpty()) View.VISIBLE else View.GONE

        recycler.adapter = object : RecyclerView.Adapter<DayViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, position: Int): DayViewHolder {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_day, parent, false)
                return DayViewHolder(view)
            }

            override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
                val day = days[position]
                holder.dayKey.text = "📅 ${day.dayKey}"
                holder.dayCount.text = "${day.count} موعد"
                holder.itemView.setOnClickListener {
                    val intent = Intent(this@ArchiveActivity, ArchiveDayActivity::class.java)
                    intent.putExtra(ArchiveDayActivity.EXTRA_DAY_KEY, day.dayKey)
                    startActivity(intent)
                }
            }

            override fun getItemCount(): Int = days.size
        }
    }

    class DayViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dayKey: TextView = view.findViewById(R.id.tvDayKey)
        val dayCount: TextView = view.findViewById(R.id.tvDayCount)
    }
}
