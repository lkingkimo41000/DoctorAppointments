package com.doctorapp.appointments

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * تُعرض مرة واحدة فقط عند أول تثبيت للتطبيق في هاتف الطبيبة:
 * تطلب رقم هاتفها الشخصي، وكلمة سر فتح التطبيق، وكلمة سر منفصلة لحذف المواعيد.
 */
class SetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        val etPhone = findViewById<EditText>(R.id.etDoctorPhone)
        val etPin = findViewById<EditText>(R.id.etPin)
        val etPinConfirm = findViewById<EditText>(R.id.etPinConfirm)
        val etDeletePass = findViewById<EditText>(R.id.etDeletePassword)
        val etDeletePassConfirm = findViewById<EditText>(R.id.etDeletePasswordConfirm)

        findViewById<MaterialButton>(R.id.btnSaveSetup).setOnClickListener {
            val phone = etPhone.text.toString().trim()
            val pin = etPin.text.toString().trim()
            val pinConfirm = etPinConfirm.text.toString().trim()
            val deletePass = etDeletePass.text.toString().trim()
            val deletePassConfirm = etDeletePassConfirm.text.toString().trim()

            if (phone.length < 6) {
                Toast.makeText(this, "أدخلي رقم هاتف صحيح", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (pin.length < 4) {
                Toast.makeText(this, "كلمة سر الفتح يجب أن تكون 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (pin != pinConfirm) {
                Toast.makeText(this, "كلمة سر الفتح غير متطابقة", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (deletePass.length < 4) {
                Toast.makeText(this, "كلمة سر الحذف يجب أن تكون 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (deletePass != deletePassConfirm) {
                Toast.makeText(this, "كلمة سر الحذف غير متطابقة", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Prefs.completeSetup(this, phone, pin, deletePass)
            Toast.makeText(this, "تم إعداد التطبيق بنجاح", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
