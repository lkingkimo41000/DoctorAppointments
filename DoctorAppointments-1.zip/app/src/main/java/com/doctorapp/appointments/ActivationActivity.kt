package com.doctorapp.appointments

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * شاشة التفعيل: تُعرض إذا لم يكن هناك كود تفعيل صالح مُسجَّل على هذا الجهاز.
 * لا يمكن تجاوز هذه الشاشة إلا بكود صحيح وفعّال يمنحه المطوّر.
 */
class ActivationActivity : AppCompatActivity() {

    private lateinit var etCode: EditText
    private lateinit var btnActivate: MaterialButton
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activation)

        etCode = findViewById(R.id.etActivationCode)
        btnActivate = findViewById(R.id.btnActivate)
        progress = findViewById(R.id.progressActivation)

        findViewById<TextView>(R.id.tvDeviceId).text =
            "معرّف الجهاز: ${LicenseManager.deviceId(this)}"

        btnActivate.setOnClickListener {
            val code = etCode.text.toString().trim()
            if (code.isBlank()) {
                Toast.makeText(this, "الرجاء إدخال كود التفعيل", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            setLoading(true)
            LicenseManager.activate(this, code) { result ->
                setLoading(false)
                if (result.success) {
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, PinLockActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        btnActivate.isEnabled = !loading
    }
}
