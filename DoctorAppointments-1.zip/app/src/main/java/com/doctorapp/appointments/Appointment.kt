package com.doctorapp.appointments

data class Appointment(
    val id: Long = 0,
    val phone: String,            // رقم المريض الحقيقي
    val name: String,             // اسم ولقب المريض
    val message: String,          // نص الرسالة الأصلي أو ملاحظة التسجيل
    val status: String,           // حالة الموعد (انظر الثوابت في DatabaseHelper)
    val createdAt: String,        // تاريخ ووقت التسجيل
    val dayKey: String,           // اليوم الذي يخص هذا الموعد (yyyy-MM-dd) لتجميع الأرشيف
    val appointmentDate: String?, // تاريخ/وقت الموعد المبرمج مسبقاً (إن وجد)، بصيغة yyyy-MM-dd HH:mm
    val isManual: Boolean,        // true إذا سجّلته الطبيبة يدوياً
    val notified48: Boolean,
    val notified24: Boolean,
    val notifiedToday: Boolean,
    val thankYouSent: Boolean
)
