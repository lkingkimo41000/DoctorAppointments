package com.doctorapp.appointments

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * أول شاشة تُفتح عند تشغيل التطبيق:
 * - إذا لم يكتمل الإعداد الأولي بعد -> تحويل إلى SetupActivity
 * - إذا اكتمل -> طلب كلمة السر قبل الدخول إلى الشاشة الرئيسية
 */
class PinLockActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // بوابة التفعيل: لا يُسمح بالمرور لأي شاشة أخرى بدون كود تفعيل صالح
        if (!LicenseManager.isLicenseValidLocally(this)) {
            startActivity(Intent(this, ActivationActivity::class.java))
            finish()
            return
        }
        // تحقق دوري في الخلفية من الخادم (لا يعطّل الواجهة)؛ إن أوقف المطوّر
        // الكود عن بعد، ستظهر شاشة التفعيل مجدداً عند فتح التطبيق القادم
        LicenseManager.revalidate(this)

        if (!Prefs.isSetupDone(this)) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_pin_lock)

        val etPin = findViewById<EditText>(R.id.etPinInput)
        findViewById<MaterialButton>(R.id.btnUnlock).setOnClickListener {
            val input = etPin.text.toString().trim()
            if (Prefs.checkPin(this, input)) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "كلمة السر غير صحيحة", Toast.LENGTH_SHORT).show()
                etPin.text.clear()
            }
        }
    }
}
