package com.doctorapp.appointments

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

/**
 * يستقبل كل رسالة SMS واردة على هاتف الطبيبة.
 * - يستخرج اسم ولقب المريض من نص الرسالة
 * - يتحقق من عدم وجود تسجيل سابق بنفس رقم الهاتف أو نفس الاسم (منع التكرار)
 * - يسجّل الموعد في قاعدة البيانات بحالة "قيد الانتظار"
 * - لا يُرسل أي رد تلقائي هنا؛ رسالة القبول تُرسل فقط عند ضغط الطبيبة
 *   على زر "قبول الموعد" داخل التطبيق
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isEmpty()) return

        // بعض الرسائل الطويلة تصل مجزأة على أكثر من segment، لهذا نجمعها
        val senderPhone = messages[0].originatingAddress ?: return
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }.trim()

        if (fullBody.isEmpty()) return

        val patientName = extractPatientName(fullBody)
        if (patientName == null) {
            Log.w("SmsReceiver", "لم يتم التعرف على اسم صالح في الرسالة: $fullBody")
            return
        }

        val db = DatabaseHelper(context)

        // منع التكرار: نفس رقم الهاتف أو نفس الاسم مسجّل مسبقاً
        if (db.existsByPhoneOrName(senderPhone, patientName)) {
            Log.i("SmsReceiver", "تسجيل مكرر تم تجاهله: $patientName / $senderPhone")
            return
        }

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        db.insertAppointment(
            phone = senderPhone,
            name = patientName,
            message = fullBody,
            status = DatabaseHelper.STATUS_PENDING,
            createdAt = timestamp
        )
    }

    /**
     * منطق استخراج الاسم من نص الرسالة.
     * حاليًا: يعتبر نص الرسالة كاملاً هو "الاسم واللقب" إذا كان يحتوي على كلمتين على الأقل
     */
    private fun extractPatientName(body: String): String? {
        val cleaned = body
            .replace("حجز", "", ignoreCase = true)
            .replace("موعد", "", ignoreCase = true)
            .replace(":", "")
            .trim()

        val words = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }

        if (words.size < 2) return null
        if (cleaned.any { it.isDigit() }) return null

        return cleaned
    }
}
