package com.doctorapp.appointments

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

/**
 * يستقبل كل رسالة SMS واردة على هاتف الطبيبة (رقمها الشخصي المبرمج عليه التطبيق).
 * - يستخرج اسم ولقب المريض من نص الرسالة
 * - يتحقق من عدم وجود تسجيل سابق بنفس رقم الهاتف أو نفس الاسم (منع التكرار)
 * - إذا كانت "خاصية استقبال المواعيد" مفتوحة: يسجَّل الموعد بحالة "قيد الانتظار"
 * - إذا كانت مغلقة (لكثرة المواعيد): يسجَّل الموعد مباشرة في قائمة "احتياط"
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isEmpty()) return

        val senderPhone = messages[0].originatingAddress ?: return
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }.trim()

        if (fullBody.isEmpty()) return

        val patientName = extractPatientName(fullBody)
        if (patientName == null) {
            Log.w("SmsReceiver", "لم يتم التعرف على اسم صالح في الرسالة: $fullBody")
            return
        }

        val db = DatabaseHelper(context)

        if (db.existsByPhoneOrName(senderPhone, patientName)) {
            Log.i("SmsReceiver", "تسجيل مكرر تم تجاهله: $patientName / $senderPhone")
            return
        }

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val targetStatus = if (Prefs.isRegistrationOpen(context)) {
            DatabaseHelper.STATUS_PENDING
        } else {
            DatabaseHelper.STATUS_RESERVE
        }

        db.insertAppointment(
            phone = senderPhone,
            name = patientName,
            message = fullBody,
            status = targetStatus,
            createdAt = timestamp
        )

        // إشعار فوري بدخول موعد جديد (صوت واهتزاز على طريقة إشعارات الرسائل الفورية)
        NotificationHelper.showNewAppointmentNotification(
            context, patientName, senderPhone, targetStatus
        )
    }

    /**
     * كلمات وعبارات شائعة في رسائل الحجز لا تُعتبر جزءاً من اسم المريض، تُحذف قبل استخراج الاسم.
     * أضف إلى هذه القائمة أي عبارة متكررة تظهر في رسائل المرضى ولا ترتبط بالاسم.
     */
    private val noiseWords = listOf(
        "حجز", "موعد", "مرحبا", "مرحباً", "السلام عليكم", "أرغب", "ارغب", "أريد", "اريد",
        "من فضلك", "رجاء", "لو سمحت", "الاسم", "الإسم", "اسمي", "إسمي", "اللقب", "الرقم",
        "طبيب", "طبيبة", "دكتور", "دكتورة", "عيادة", "استشارة", "كشف", "تسجيل"
    )

    private fun extractPatientName(body: String): String? {
        var cleaned = body
        for (word in noiseWords) {
            cleaned = cleaned.replace(word, "", ignoreCase = true)
        }
        cleaned = cleaned
            .replace(Regex("[:،.!؟?-]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // إزالة أي رقم هاتف أو رقم مضمّن داخل النص (لا يُعتبر جزءاً من الاسم)
        val words = cleaned.split(" ")
            .filter { it.isNotBlank() && it.none { ch -> ch.isDigit() } }

        if (words.size < 2) return null

        // يُبقي فقط على أول كلمتين إلى ثلاث كلمات (الاسم واللقب، مع هامش لاسم مركّب)
        return words.take(3).joinToString(" ")
    }
}
