package com.doctorapp.appointments

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class AppointmentAdapter(
    private var items: List<Appointment>,
    private val onDelete: (Appointment) -> Unit,
    private val onAccept: (Appointment) -> Unit,
    private val onEnterDoctor: (Appointment) -> Unit
) : RecyclerView.Adapter<AppointmentAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.tvAvatar)
        val nameText: TextView = view.findViewById(R.id.tvName)
        val phoneText: TextView = view.findViewById(R.id.tvPhone)
        val statusText: TextView = view.findViewById(R.id.tvStatus)
        val dateText: TextView = view.findViewById(R.id.tvDate)
        val deleteBtn: View = view.findViewById(R.id.btnDelete)
        val acceptBtn: MaterialButton = view.findViewById(R.id.btnAccept)
        val enterDoctorBtn: MaterialButton = view.findViewById(R.id.btnEnterDoctor)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context

        holder.nameText.text = item.name
        holder.phoneText.text = item.phone
        holder.dateText.text = item.createdAt
        holder.avatar.text = item.name.trim().firstOrNull()?.toString() ?: "؟"
        holder.statusText.text = item.status

        when (item.status) {
            DatabaseHelper.STATUS_PENDING -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_pending)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusPendingText))
                holder.acceptBtn.visibility = View.VISIBLE
                holder.enterDoctorBtn.visibility = View.GONE
            }
            DatabaseHelper.STATUS_CONFIRMED -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_confirmed)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusConfirmedText))
                holder.acceptBtn.visibility = View.GONE
                holder.enterDoctorBtn.visibility = View.VISIBLE
            }
            DatabaseHelper.STATUS_IN_PROGRESS -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_progress)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusProgressText))
                holder.acceptBtn.visibility = View.GONE
                holder.enterDoctorBtn.visibility = View.GONE
            }
            else -> {
                holder.acceptBtn.visibility = View.GONE
                holder.enterDoctorBtn.visibility = View.GONE
            }
        }

        holder.deleteBtn.setOnClickListener { onDelete(item) }
        holder.acceptBtn.setOnClickListener { onAccept(item) }
        holder.enterDoctorBtn.setOnClickListener { onEnterDoctor(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<Appointment>) {
        items = newItems
        notifyDataSetChanged()
    }
}
