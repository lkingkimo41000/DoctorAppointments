package com.doctorapp.appointments

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class AppointmentAdapter(
    private var items: List<Appointment>,
    private val onDeleteRequest: (Appointment) -> Unit,
    private val onCall: (Appointment) -> Unit,
    private val onAccept: (Appointment) -> Unit,
    private val onMoveFromReserve: (Appointment) -> Unit,
    private val onAbsent: (Appointment) -> Unit,
    private val onEnterDoctor: (Appointment) -> Unit,
    private val onFinish: (Appointment) -> Unit,
    private val onRestore: (Appointment) -> Unit,
    private val readOnly: Boolean = false
) : RecyclerView.Adapter<AppointmentAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.tvAvatar)
        val nameText: TextView = view.findViewById(R.id.tvName)
        val phoneText: TextView = view.findViewById(R.id.tvPhone)
        val statusText: TextView = view.findViewById(R.id.tvStatus)
        val scheduledTag: TextView = view.findViewById(R.id.tvScheduledTag)
        val dateText: TextView = view.findViewById(R.id.tvDate)
        val noteText: TextView = view.findViewById(R.id.tvNote)
        val callBtn: View = view.findViewById(R.id.btnCall)
        val deleteBtn: View = view.findViewById(R.id.btnDelete)
        val acceptBtn: MaterialButton = view.findViewById(R.id.btnAccept)
        val moveMainBtn: MaterialButton = view.findViewById(R.id.btnMoveMain)
        val enterDoctorBtn: MaterialButton = view.findViewById(R.id.btnEnterDoctor)
        val finishBtn: MaterialButton = view.findViewById(R.id.btnFinish)
        val restoreBtn: MaterialButton = view.findViewById(R.id.btnRestore)
        val absentBtn: MaterialButton = view.findViewById(R.id.btnAbsent)
        val rowTwo: View = view.findViewById(R.id.actionsRowTwo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context

        holder.nameText.text = item.name
        holder.phoneText.text = item.phone
        holder.dateText.text = item.createdAt
        holder.avatar.text = item.name.trim().firstOrNull()?.toString() ?: "؟"
        holder.statusText.text = item.status

        if (item.isManual && item.message.isNotBlank()) {
            holder.noteText.visibility = View.VISIBLE
            holder.noteText.text = "📝 ${item.message}"
        } else {
            holder.noteText.visibility = View.GONE
        }

        if (!item.appointmentDate.isNullOrBlank()) {
            holder.scheduledTag.visibility = View.VISIBLE
            holder.scheduledTag.text = "📅 ${item.appointmentDate}"
        } else {
            holder.scheduledTag.visibility = View.GONE
        }

        // إخفاء كل الأزرار افتراضياً، ثم إظهار ما يلزم حسب الحالة
        holder.acceptBtn.visibility = View.GONE
        holder.moveMainBtn.visibility = View.GONE
        holder.enterDoctorBtn.visibility = View.GONE
        holder.finishBtn.visibility = View.GONE
        holder.restoreBtn.visibility = View.GONE
        holder.absentBtn.visibility = View.GONE
        holder.callBtn.visibility = View.VISIBLE
        holder.rowTwo.visibility = View.VISIBLE

        when (item.status) {
            DatabaseHelper.STATUS_PENDING -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_pending)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusPendingText))
                holder.acceptBtn.visibility = View.VISIBLE
                holder.absentBtn.visibility = View.VISIBLE
            }
            DatabaseHelper.STATUS_RESERVE -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_reserve)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusReserveText))
                holder.moveMainBtn.visibility = View.VISIBLE
                holder.absentBtn.visibility = View.VISIBLE
            }
            DatabaseHelper.STATUS_CONFIRMED -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_confirmed)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusConfirmedText))
                holder.enterDoctorBtn.visibility = View.VISIBLE
                holder.enterDoctorBtn.text = "🚪 دخل عند ${Prefs.getDoctorTitle(context)}"
                holder.absentBtn.visibility = View.VISIBLE
            }
            DatabaseHelper.STATUS_IN_PROGRESS -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_progress)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusProgressText))
                holder.finishBtn.visibility = View.VISIBLE
                holder.rowTwo.visibility = View.GONE
            }
            DatabaseHelper.STATUS_ABSENT -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_absent)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusAbsentText))
                holder.restoreBtn.visibility = View.VISIBLE
                holder.rowTwo.visibility = View.GONE
            }
            DatabaseHelper.STATUS_FINISHED -> {
                holder.statusText.setBackgroundResource(R.drawable.status_bg_finished)
                holder.statusText.setTextColor(ContextCompat.getColor(context, R.color.statusFinishedText))
                holder.callBtn.visibility = View.GONE
                holder.rowTwo.visibility = View.GONE
            }
            else -> {
                holder.rowTwo.visibility = View.GONE
            }
        }

        if (readOnly) {
            holder.acceptBtn.visibility = View.GONE
            holder.moveMainBtn.visibility = View.GONE
            holder.enterDoctorBtn.visibility = View.GONE
            holder.finishBtn.visibility = View.GONE
            holder.restoreBtn.visibility = View.GONE
            holder.absentBtn.visibility = View.GONE
            holder.rowTwo.visibility = View.GONE
        }

        holder.deleteBtn.setOnClickListener { onDeleteRequest(item) }
        holder.callBtn.setOnClickListener { onCall(item) }
        holder.acceptBtn.setOnClickListener { onAccept(item) }
        holder.moveMainBtn.setOnClickListener { onMoveFromReserve(item) }
        holder.absentBtn.setOnClickListener { onAbsent(item) }
        holder.enterDoctorBtn.setOnClickListener { onEnterDoctor(item) }
        holder.finishBtn.setOnClickListener { onFinish(item) }
        holder.restoreBtn.setOnClickListener { onRestore(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<Appointment>) {
        items = newItems
        notifyDataSetChanged()
    }
}
