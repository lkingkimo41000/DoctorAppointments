package com.doctorapp.appointments

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: AppointmentAdapter
    private lateinit var tvPendingCount: TextView
    private lateinit var tvConfirmedCount: TextView
    private lateinit var tvProgressCount: TextView
    private lateinit var tvReserveCount: TextView
    private lateinit var tvRegistrationLabel: TextView
    private lateinit var switchRegistration: SwitchMaterial

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.SEND_SMS,
        Manifest.permission.CALL_PHONE
    )
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // حماية إضافية: إذا لم يكتمل الإعداد الأولي، أو حاول أحد فتح هذه الشاشة
        // مباشرة بدون المرور من شاشة كلمة السر، نعيده إلى شاشة القفل
        if (!Prefs.isSetupDone(this)) {
            startActivity(Intent(this, PinLockActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)
        tvPendingCount = findViewById(R.id.tvPendingCount)
        tvConfirmedCount = findViewById(R.id.tvConfirmedCount)
        tvProgressCount = findViewById(R.id.tvProgressCount)
        tvReserveCount = findViewById(R.id.tvReserveCount)
        tvRegistrationLabel = findViewById(R.id.tvRegistrationLabel)
        switchRegistration = findViewById(R.id.switchRegistration)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AppointmentAdapter(
            items = emptyList(),
            onDeleteRequest = { appointment ->
                AppUtils.requestDeletePassword(this) {
                    db.deleteAppointment(appointment.id)
                    Toast.makeText(this, "تم حذف الموعد نهائياً", Toast.LENGTH_SHORT).show()
                    refreshList()
                }
            },
            onCall = { appointment ->
                AppUtils.callPatient(this, appointment.phone)
            },
            onAccept = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_CONFIRMED)
                SmsSender.sendAcceptance(this, appointment.phone, appointment.name)
                Toast.makeText(this, "تم قبول الموعد وإرسال رسالة التأكيد للمريض", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onMoveFromReserve = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_PENDING)
                Toast.makeText(this, "تم نقل ${appointment.name} إلى قائمة الانتظار الرئيسية", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onAbsent = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_ABSENT)
                Toast.makeText(this, "تم نقل ${appointment.name} إلى قائمة الغير حاضرين", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onEnterDoctor = { appointment ->
                handlePatientEntered(appointment)
            },
            onFinish = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_FINISHED)
                SmsSender.sendThankYou(this, appointment.phone, appointment.name)
                db.setThankYouSent(appointment.id)
                Toast.makeText(this, "تم إنهاء الكشف وإرسال رسالة الشكر للمريض", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onRestore = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_PENDING)
                Toast.makeText(this, "تم إرجاع ${appointment.name} إلى قائمة الانتظار", Toast.LENGTH_SHORT).show()
                refreshList()
            }
        )
        recyclerView.adapter = adapter

        findViewById<MaterialButton>(R.id.btnRefresh).setOnClickListener { refreshList() }

        findViewById<MaterialButton>(R.id.btnClearAll).setOnClickListener {
            AppUtils.requestDeletePassword(this) {
                db.getTodayAppointments().forEach { db.deleteAppointment(it.id) }
                refreshList()
                Toast.makeText(this, "تم مسح كل مواعيد اليوم", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<MaterialButton>(R.id.btnManualAdd).setOnClickListener {
            startActivity(Intent(this, ManualAddActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnSchedule).setOnClickListener {
            startActivity(Intent(this, ScheduleAppointmentActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnSearchPatient).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnArchive).setOnClickListener {
            startActivity(Intent(this, ArchiveActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        switchRegistration.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setRegistrationOpen(this, isChecked)
            updateRegistrationLabel(isChecked)
            db.logOperation(
                "تغيير حالة استقبال المواعيد",
                if (isChecked) "تم فتح الاستقبال" else "تم إغلاق الاستقبال (احتياط)"
            )
        }

        checkAndRequestPermissions()
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        // إعادة قراءة الإعدادات في حال تم تعديلها من شاشة الإعدادات
        switchRegistration.setOnCheckedChangeListener(null)
        val isOpen = Prefs.isRegistrationOpen(this)
        switchRegistration.isChecked = isOpen
        updateRegistrationLabel(isOpen)
        switchRegistration.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setRegistrationOpen(this, isChecked)
            updateRegistrationLabel(isChecked)
        }
        refreshList()
    }

    private fun updateRegistrationLabel(open: Boolean) {
        tvRegistrationLabel.text = if (open) {
            "🟢 استقبال المواعيد الجديدة: مفتوح"
        } else {
            "🔴 استقبال المواعيد الجديدة: مغلق (تُسجَّل في الاحتياط)"
        }
    }

    /**
     * عند ضغط الطبيبة على زر "دخل عند الطبيبة" لمريض معيّن:
     * - نأخذ لقطة من قائمة الانتظار المؤكدة لليوم قبل تغيير حالة هذا المريض
     * - نحدّد ترتيبه، ثم نحسب "المريض الثالث" بدءاً من المريض الداخل حالياً
     * - نرسل له رسالة تنبيه أن موعده بعد 30 دقيقة
     */
    private fun handlePatientEntered(appointment: Appointment) {
        val queueBefore = db.getConfirmedQueue()
        val idx = queueBefore.indexOfFirst { it.id == appointment.id }

        db.updateStatus(appointment.id, DatabaseHelper.STATUS_IN_PROGRESS)

        if (idx >= 0) {
            val remaining = queueBefore.filterIndexed { i, _ -> i != idx }
            if (remaining.size >= 2) {
                val thirdPatient = remaining[1]
                SmsSender.sendThirtyMinuteNotice(this, thirdPatient.phone, thirdPatient.name)
                Toast.makeText(
                    this,
                    "تم إشعار ${thirdPatient.name} بأن موعده بعد 30 دقيقة",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, "لا يوجد مريض ثالث في قائمة الانتظار حالياً", Toast.LENGTH_SHORT).show()
            }
        }
        refreshList()
    }

    private fun refreshList() {
        val appointments = db.getTodayAppointments()
        adapter.updateData(appointments)
        tvPendingCount.text = db.countByStatusToday(DatabaseHelper.STATUS_PENDING).toString()
        tvConfirmedCount.text = db.countByStatusToday(DatabaseHelper.STATUS_CONFIRMED).toString()
        tvProgressCount.text = db.countByStatusToday(DatabaseHelper.STATUS_IN_PROGRESS).toString()
        tvReserveCount.text = db.countByStatusToday(DatabaseHelper.STATUS_RESERVE).toString()
    }

    private fun checkAndRequestPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (!allGranted) {
                Toast.makeText(
                    this,
                    "يجب منح كل الصلاحيات (الرسائل والاتصال) ليعمل التطبيق بشكل صحيح",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
