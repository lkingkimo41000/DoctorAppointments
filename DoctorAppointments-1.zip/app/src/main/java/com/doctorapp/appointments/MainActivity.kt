package com.doctorapp.appointments

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: AppointmentAdapter
    private lateinit var tvPendingCount: TextView
    private lateinit var tvConfirmedCount: TextView
    private lateinit var tvProgressCount: TextView

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.SEND_SMS
    )
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)
        tvPendingCount = findViewById(R.id.tvPendingCount)
        tvConfirmedCount = findViewById(R.id.tvConfirmedCount)
        tvProgressCount = findViewById(R.id.tvProgressCount)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AppointmentAdapter(
            items = emptyList(),
            onDelete = { appointment ->
                db.deleteAppointment(appointment.id)
                refreshList()
            },
            onAccept = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_CONFIRMED)
                SmsSender.sendAcceptance(this, appointment.phone, appointment.name)
                Toast.makeText(this, "تم قبول الموعد وإرسال رسالة التأكيد للمريض", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onEnterDoctor = { appointment ->
                handlePatientEntered(appointment)
            }
        )
        recyclerView.adapter = adapter

        findViewById<MaterialButton>(R.id.btnRefresh).setOnClickListener { refreshList() }
        findViewById<MaterialButton>(R.id.btnClearAll).setOnClickListener {
            db.deleteAll()
            refreshList()
            Toast.makeText(this, "تم مسح كل المواعيد", Toast.LENGTH_SHORT).show()
        }

        checkAndRequestPermissions()
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    /**
     * عند ضغط الطبيبة على زر "دخل عند الطبيبة" لمريض معيّن:
     * - نأخذ لقطة من قائمة الانتظار المؤكدة قبل تغيير حالة هذا المريض
     * - نحدّد ترتيبه، ثم نحسب "المريض الثالث" بدءاً من المريض الداخل حالياً
     *   (يعني: الداخل = الأول، التالي له = الثاني، وبعده = الثالث)
     * - نرسل له رسالة تنبيه أن موعده بعد 30 دقيقة
     */
    private fun handlePatientEntered(appointment: Appointment) {
        val queueBefore = db.getConfirmedQueue()
        val idx = queueBefore.indexOfFirst { it.id == appointment.id }

        db.updateStatus(appointment.id, DatabaseHelper.STATUS_IN_PROGRESS)

        if (idx >= 0) {
            val remaining = queueBefore.filterIndexed { i, _ -> i != idx }
            // remaining[0] = المريض الثاني في الدور، remaining[1] = المريض الثالث
            if (remaining.size >= 2) {
                val thirdPatient = remaining[1]
                SmsSender.sendThirtyMinuteNotice(this, thirdPatient.phone, thirdPatient.name)
                Toast.makeText(
                    this,
                    "تم إشعار ${thirdPatient.name} بأن موعده بعد 30 دقيقة",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, "لا يوجد مريض ثالث في قائمة الانتظار حالياً", Toast.LENGTH_SHORT).show()
            }
        }
        refreshList()
    }

    private fun refreshList() {
        val appointments = db.getAllAppointments()
        adapter.updateData(appointments)
        tvPendingCount.text = db.countByStatus(DatabaseHelper.STATUS_PENDING).toString()
        tvConfirmedCount.text = db.countByStatus(DatabaseHelper.STATUS_CONFIRMED).toString()
        tvProgressCount.text = db.countByStatus(DatabaseHelper.STATUS_IN_PROGRESS).toString()
    }

    private fun checkAndRequestPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (!allGranted) {
                Toast.makeText(
                    this,
                    "يجب منح صلاحيات الرسائل ليعمل التطبيق بشكل صحيح",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
