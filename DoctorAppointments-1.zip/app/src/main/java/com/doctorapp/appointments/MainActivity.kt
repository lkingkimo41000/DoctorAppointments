package com.doctorapp.appointments

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: AppointmentAdapter
    private lateinit var tvPendingCount: TextView
    private lateinit var tvConfirmedCount: TextView
    private lateinit var tvProgressCount: TextView
    private lateinit var tvReserveCount: TextView
    private lateinit var tvRegistrationLabel: TextView
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvLicenseCountdown: TextView
    private lateinit var switchRegistration: SwitchMaterial

    private val autoRefreshHandler = Handler(Looper.getMainLooper())
    private val autoRefreshRunnable = object : Runnable {
        override fun run() {
            refreshList()
            autoRefreshHandler.postDelayed(this, 1000L)
        }
    }

    // تحقق دوري كل 60 ثانية من صلاحية التفعيل أثناء استخدام التطبيق، حتى ينعكس
    // أي إلغاء يقوم به المطوّر عن بعد دون الحاجة لإغلاق التطبيق وإعادة فتحه
    private val licenseCheckHandler = Handler(Looper.getMainLooper())
    private val licenseCheckRunnable = object : Runnable {
        override fun run() {
            LicenseManager.revalidate(this@MainActivity) { valid ->
                if (!valid) {
                    Toast.makeText(
                        this@MainActivity,
                        "انتهت صلاحية التفعيل، يرجى التواصل مع المطوّر",
                        Toast.LENGTH_LONG
                    ).show()
                    startActivity(Intent(this@MainActivity, ActivationActivity::class.java))
                    finish()
                } else {
                    updateLicenseCountdown()
                }
            }
            licenseCheckHandler.postDelayed(this, 60_000L)
        }
    }

    private val requiredPermissions: Array<String>
        get() {
            val base = mutableListOf(
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.CALL_PHONE
            )
            // إذن إظهار الإشعارات مطلوب فقط من أندرويد 13 (API 33) فما فوق
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                base.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            return base.toTypedArray()
        }
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // حماية إضافية: إذا لم يكتمل الإعداد الأولي، أو انتهى التفعيل، أو حاول
        // أحد فتح هذه الشاشة مباشرة بدون المرور من شاشة كلمة السر
        if (!Prefs.isSetupDone(this) || !LicenseManager.isLicenseValidLocally(this)) {
            startActivity(Intent(this, PinLockActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        NotificationHelper.createChannel(this)

        db = DatabaseHelper(this)
        tvPendingCount = findViewById(R.id.tvPendingCount)
        tvConfirmedCount = findViewById(R.id.tvConfirmedCount)
        tvProgressCount = findViewById(R.id.tvProgressCount)
        tvReserveCount = findViewById(R.id.tvReserveCount)
        tvRegistrationLabel = findViewById(R.id.tvRegistrationLabel)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvLicenseCountdown = findViewById(R.id.tvLicenseCountdown)
        switchRegistration = findViewById(R.id.switchRegistration)

        // عنوان الصفحة يعكس صيغة الخطاب المختارة عند التهيئة (طبيب / طبيبة)
        tvHeaderTitle.text = "🏥 نظام حجز مواعيد ${Prefs.getDoctorTitle(this)}"

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AppointmentAdapter(
            items = emptyList(),
            onDeleteRequest = { appointment ->
                AppUtils.requestDeletePassword(this) {
                    db.deleteAppointment(appointment.id)
                    Toast.makeText(this, "تم حذف الموعد نهائياً", Toast.LENGTH_SHORT).show()
                    refreshList()
                }
            },
            onCall = { appointment ->
                AppUtils.callPatient(this, appointment.phone)
            },
            onAccept = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_CONFIRMED)
                SmsSender.sendAcceptance(this, appointment.phone, appointment.name)
                Toast.makeText(this, "تم قبول الموعد وإرسال رسالة التأكيد للمريض", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onMoveFromReserve = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_PENDING)
                Toast.makeText(this, "تم نقل ${appointment.name} إلى قائمة الانتظار الرئيسية", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onAbsent = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_ABSENT)
                Toast.makeText(this, "تم نقل ${appointment.name} إلى قائمة الغير حاضرين", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onEnterDoctor = { appointment ->
                handlePatientEntered(appointment)
            },
            onFinish = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_FINISHED)
                SmsSender.sendThankYou(this, appointment.phone, appointment.name)
                db.setThankYouSent(appointment.id)
                Toast.makeText(this, "تم إنهاء الكشف وإرسال رسالة الشكر للمريض", Toast.LENGTH_SHORT).show()
                refreshList()
            },
            onRestore = { appointment ->
                db.updateStatus(appointment.id, DatabaseHelper.STATUS_PENDING)
                Toast.makeText(this, "تم إرجاع ${appointment.name} إلى قائمة الانتظار", Toast.LENGTH_SHORT).show()
                refreshList()
            }
        )
        recyclerView.adapter = adapter

        setupNavButton(R.id.navManualAdd, "➕", "إضافة يدوية") {
            startActivity(Intent(this, ManualAddActivity::class.java))
        }
        setupNavButton(R.id.navSchedule, "📅", "برمجة موعد") {
            startActivity(Intent(this, ScheduleAppointmentActivity::class.java))
        }
        setupNavButton(R.id.navSearch, "🔍", "بحث") {
            startActivity(Intent(this, SearchActivity::class.java))
        }
        setupNavButton(R.id.navArchive, "📁", "الأرشيف") {
            startActivity(Intent(this, ArchiveActivity::class.java))
        }
        setupNavButton(R.id.navSettings, "⚙️", "إعدادات") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        setupNavButton(R.id.navRefresh, "🔄", "تحديث") {
            refreshList()
        }

        findViewById<MaterialButton>(R.id.btnClearAll).setOnClickListener {
            AppUtils.requestDeletePassword(this) {
                db.getTodayAppointments().forEach { db.deleteAppointment(it.id) }
                refreshList()
                Toast.makeText(this, "تم مسح كل مواعيد اليوم", Toast.LENGTH_SHORT).show()
            }
        }

        switchRegistration.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setRegistrationOpen(this, isChecked)
            updateRegistrationLabel(isChecked)
            db.logOperation(
                "تغيير حالة استقبال المواعيد",
                if (isChecked) "تم فتح الاستقبال" else "تم إغلاق الاستقبال (احتياط)"
            )
        }

        checkAndRequestPermissions()
        refreshList()
        updateLicenseCountdown()
    }

    /** تهيئة بطاقة تنقل (أيقونة + تسمية) مُضمَّنة عبر <include> في activity_main.xml */
    private fun setupNavButton(containerId: Int, icon: String, label: String, onClick: () -> Unit) {
        val container = findViewById<View>(containerId)
        container.findViewById<TextView>(R.id.tvNavIcon).text = icon
        container.findViewById<TextView>(R.id.tvNavLabel).text = label
        container.setOnClickListener { onClick() }
    }

    override fun onResume() {
        super.onResume()

        // فحص فوري: إن أوقف المطوّر التفعيل بينما التطبيق كان في الخلفية
        if (!LicenseManager.isLicenseValidLocally(this)) {
            startActivity(Intent(this, ActivationActivity::class.java))
            finish()
            return
        }

        // إعادة قراءة الإعدادات في حال تم تعديلها من شاشة الإعدادات
        switchRegistration.setOnCheckedChangeListener(null)
        val isOpen = Prefs.isRegistrationOpen(this)
        switchRegistration.isChecked = isOpen
        updateRegistrationLabel(isOpen)
        switchRegistration.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setRegistrationOpen(this, isChecked)
            updateRegistrationLabel(isChecked)
        }
        tvHeaderTitle.text = "🏥 نظام حجز مواعيد ${Prefs.getDoctorTitle(this)}"
        updateLicenseCountdown()
        refreshList()

        // تشغيل التحديث التلقائي للقائمة كل ثانية (بدل الاعتماد على الزر اليدوي)
        autoRefreshHandler.postDelayed(autoRefreshRunnable, 1000L)
        // تشغيل التحقق الدوري من صلاحية التفعيل
        licenseCheckHandler.postDelayed(licenseCheckRunnable, 60_000L)
    }

    override fun onPause() {
        super.onPause()
        autoRefreshHandler.removeCallbacks(autoRefreshRunnable)
        licenseCheckHandler.removeCallbacks(licenseCheckRunnable)
    }

    /** يعرض عدد الأيام المتبقية على انتهاء كود التفعيل، مع تلوين تحذيري عند اقترابه */
    private fun updateLicenseCountdown() {
        val remaining = Prefs.getLicenseRemainingDays(this)
        tvLicenseCountdown.text = if (remaining <= 0) {
            "🔑 التفعيل منتهي — يرجى تجديد الكود"
        } else {
            "🔑 الأيام المتبقية على التفعيل: $remaining يوم"
        }
    }

    private fun updateRegistrationLabel(open: Boolean) {
        tvRegistrationLabel.text = if (open) {
            "🟢 استقبال المواعيد الجديدة: مفتوح"
        } else {
            "🔴 استقبال المواعيد الجديدة: مغلق (تُسجَّل في الاحتياط)"
        }
    }

    /**
     * عند ضغط الطبيب/ة على زر "دخل عند الطبيب/ة" لمريض معيّن:
     * - نأخذ لقطة من قائمة الانتظار المؤكدة لليوم قبل تغيير حالة هذا المريض
     * - نحدّد ترتيبه، ثم نحسب "المريض الثالث" بدءاً من المريض الداخل حالياً
     * - نرسل له رسالة تنبيه أن موعده بعد 30 دقيقة
     */
    private fun handlePatientEntered(appointment: Appointment) {
        val queueBefore = db.getConfirmedQueue()
        val idx = queueBefore.indexOfFirst { it.id == appointment.id }

        db.updateStatus(appointment.id, DatabaseHelper.STATUS_IN_PROGRESS)

        if (idx >= 0) {
            val remaining = queueBefore.filterIndexed { i, _ -> i != idx }
            if (remaining.size >= 2) {
                val thirdPatient = remaining[1]
                SmsSender.sendThirtyMinuteNotice(this, thirdPatient.phone, thirdPatient.name)
                Toast.makeText(
                    this,
                    "تم إشعار ${thirdPatient.name} بأن موعده بعد 30 دقيقة",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, "لا يوجد مريض ثالث في قائمة الانتظار حالياً", Toast.LENGTH_SHORT).show()
            }
        }
        refreshList()
    }

    private fun refreshList() {
        val appointments = db.getTodayAppointments()
        adapter.updateData(appointments)
        tvPendingCount.text = db.countByStatusToday(DatabaseHelper.STATUS_PENDING).toString()
        tvConfirmedCount.text = db.countByStatusToday(DatabaseHelper.STATUS_CONFIRMED).toString()
        tvProgressCount.text = db.countByStatusToday(DatabaseHelper.STATUS_IN_PROGRESS).toString()
        tvReserveCount.text = db.countByStatusToday(DatabaseHelper.STATUS_RESERVE).toString()
    }

    private fun checkAndRequestPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (!allGranted) {
                Toast.makeText(
                    this,
                    "يجب منح كل الصلاحيات (الرسائل والاتصال) ليعمل التطبيق بشكل صحيح",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
