package com.doctorapp.appointments

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * يُستدعى من AlarmManager في وقت كل تنبيه (48 ساعة / 24 ساعة / يوم الموعد)
 * فيرسل رسالة SMS المناسبة للمريض ويسجّل أن التنبيه أُرسل حتى لا يتكرر.
 */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_APPOINTMENT_ID = "appointment_id"
        const val EXTRA_TYPE = "reminder_type"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val appointmentId = intent.getLongExtra(EXTRA_APPOINTMENT_ID, -1L)
        val type = intent.getStringExtra(EXTRA_TYPE) ?: return
        if (appointmentId < 0) return

        val db = DatabaseHelper(context)
        val appointment = db.getAppointmentById(appointmentId) ?: return

        // إذا حُذف الموعد أو أُلغي أو انتهت زيارته فعلاً، لا نرسل التنبيه
        if (appointment.status == DatabaseHelper.STATUS_FINISHED || appointment.status == DatabaseHelper.STATUS_ABSENT) {
            return
        }

        val dateTime = appointment.appointmentDate ?: appointment.createdAt

        when (type) {
            ReminderScheduler.TYPE_48H -> {
                SmsSender.sendReminder48h(context, appointment.phone, appointment.name, dateTime)
                db.setNotifiedFlag(appointmentId, DatabaseHelper.COL_NOTIFIED_48)
            }
            ReminderScheduler.TYPE_24H -> {
                SmsSender.sendReminder24h(context, appointment.phone, appointment.name, dateTime)
                db.setNotifiedFlag(appointmentId, DatabaseHelper.COL_NOTIFIED_24)
            }
            ReminderScheduler.TYPE_TODAY -> {
                SmsSender.sendReminderToday(context, appointment.phone, appointment.name, dateTime)
                db.setNotifiedFlag(appointmentId, DatabaseHelper.COL_NOTIFIED_TODAY)
            }
        }
        db.logOperation("إرسال تذكير موعد ($type)", "${appointment.name} / ${appointment.phone}")
    }
}
