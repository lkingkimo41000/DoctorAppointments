package com.doctorapp.appointments

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "appointments.db"
        private const val DB_VERSION = 1
        const val TABLE_NAME = "appointments"

        const val COL_ID = "id"
        const val COL_PHONE = "phone"
        const val COL_NAME = "name"
        const val COL_MESSAGE = "message"
        const val COL_STATUS = "status"
        const val COL_CREATED_AT = "created_at"

        const val STATUS_PENDING = "قيد الانتظار"
        const val STATUS_CONFIRMED = "مؤكد"
        const val STATUS_IN_PROGRESS = "قيد الكشف"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_PHONE TEXT NOT NULL,
                $COL_NAME TEXT NOT NULL,
                $COL_MESSAGE TEXT,
                $COL_STATUS TEXT DEFAULT '$STATUS_PENDING',
                $COL_CREATED_AT TEXT
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // إضافة موعد جديد، يرجع الـ id الجديد
    fun insertAppointment(phone: String, name: String, message: String, status: String, createdAt: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_PHONE, phone)
            put(COL_NAME, name)
            put(COL_MESSAGE, message)
            put(COL_STATUS, status)
            put(COL_CREATED_AT, createdAt)
        }
        val id = db.insert(TABLE_NAME, null, values)
        db.close()
        return id
    }

    // يتحقق هل يوجد مسبقاً تسجيل بنفس رقم الهاتف أو نفس اسم المريض (منع التكرار)
    fun existsByPhoneOrName(phone: String, name: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, arrayOf(COL_ID),
            "$COL_PHONE = ? OR $COL_NAME = ?",
            arrayOf(phone, name),
            null, null, null
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    // تحديث حالة موعد معيّن (مثلاً بعد القبول أو دخول المريض عند الطبيبة)
    fun updateStatus(id: Long, status: String) {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_STATUS, status) }
        db.update(TABLE_NAME, values, "$COL_ID = ?", arrayOf(id.toString()))
        db.close()
    }

    // جلب كل المواعيد مرتبة من الأحدث للأقدم (للعرض في القائمة)
    fun getAllAppointments(): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null, null, null, null, null,
            "$COL_ID DESC"
        )
        while (cursor.moveToNext()) {
            list.add(cursorToAppointment(cursor))
        }
        cursor.close()
        db.close()
        return list
    }

    // قائمة انتظار المرضى "المؤكدين" مرتبة حسب ترتيب التسجيل (الأقدم أولاً) لحساب دور كل مريض
    fun getConfirmedQueue(): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null,
            "$COL_STATUS = ?", arrayOf(STATUS_CONFIRMED),
            null, null,
            "$COL_ID ASC"
        )
        while (cursor.moveToNext()) {
            list.add(cursorToAppointment(cursor))
        }
        cursor.close()
        db.close()
        return list
    }

    // عدد المواعيد حسب الحالة (لعرض الإحصائيات أعلى الشاشة)
    fun countByStatus(status: String): Int {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, arrayOf(COL_ID),
            "$COL_STATUS = ?", arrayOf(status),
            null, null, null
        )
        val count = cursor.count
        cursor.close()
        db.close()
        return count
    }

    fun deleteAll() {
        val db = writableDatabase
        db.delete(TABLE_NAME, null, null)
        db.close()
    }

    fun deleteAppointment(id: Long) {
        val db = writableDatabase
        db.delete(TABLE_NAME, "$COL_ID = ?", arrayOf(id.toString()))
        db.close()
    }

    private fun cursorToAppointment(cursor: android.database.Cursor): Appointment {
        return Appointment(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
            phone = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE)),
            name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
            message = cursor.getString(cursor.getColumnIndexOrThrow(COL_MESSAGE)),
            status = cursor.getString(cursor.getColumnIndexOrThrow(COL_STATUS)),
            createdAt = cursor.getString(cursor.getColumnIndexOrThrow(COL_CREATED_AT))
        )
    }
}
