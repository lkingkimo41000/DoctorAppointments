package com.doctorapp.appointments

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "appointments.db"
        private const val DB_VERSION = 2
        const val TABLE_NAME = "appointments"
        const val TABLE_LOG = "operations_log"

        const val COL_ID = "id"
        const val COL_PHONE = "phone"
        const val COL_NAME = "name"
        const val COL_MESSAGE = "message"
        const val COL_STATUS = "status"
        const val COL_CREATED_AT = "created_at"
        const val COL_DAY_KEY = "day_key"
        const val COL_APPT_DATE = "appointment_date"
        const val COL_IS_MANUAL = "is_manual"
        const val COL_NOTIFIED_48 = "notified_48"
        const val COL_NOTIFIED_24 = "notified_24"
        const val COL_NOTIFIED_TODAY = "notified_today"
        const val COL_THANK_YOU_SENT = "thank_you_sent"

        const val LOG_ID = "id"
        const val LOG_TIME = "log_time"
        const val LOG_ACTION = "action"
        const val LOG_DETAILS = "details"

        // حالات الموعد
        const val STATUS_PENDING = "قيد الانتظار"
        const val STATUS_CONFIRMED = "مؤكد"
        const val STATUS_IN_PROGRESS = "قيد الكشف"
        const val STATUS_RESERVE = "احتياط"
        const val STATUS_ABSENT = "غير حاضر"
        const val STATUS_FINISHED = "منتهي"

        val DAY_FORMAT = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val DATETIME_FORMAT = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

        fun todayKey(): String = DAY_FORMAT.format(Date())
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE_NAME (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_PHONE TEXT NOT NULL,
                $COL_NAME TEXT NOT NULL,
                $COL_MESSAGE TEXT,
                $COL_STATUS TEXT DEFAULT '$STATUS_PENDING',
                $COL_CREATED_AT TEXT,
                $COL_DAY_KEY TEXT,
                $COL_APPT_DATE TEXT,
                $COL_IS_MANUAL INTEGER DEFAULT 0,
                $COL_NOTIFIED_48 INTEGER DEFAULT 0,
                $COL_NOTIFIED_24 INTEGER DEFAULT 0,
                $COL_NOTIFIED_TODAY INTEGER DEFAULT 0,
                $COL_THANK_YOU_SENT INTEGER DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE $TABLE_LOG (
                $LOG_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $LOG_TIME TEXT,
                $LOG_ACTION TEXT,
                $LOG_DETAILS TEXT
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_DAY_KEY TEXT")
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_APPT_DATE TEXT")
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_IS_MANUAL INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_NOTIFIED_48 INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_NOTIFIED_24 INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_NOTIFIED_TODAY INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COL_THANK_YOU_SENT INTEGER DEFAULT 0")
            db.execSQL(
                "UPDATE $TABLE_NAME SET $COL_DAY_KEY = substr($COL_CREATED_AT, 1, 10) WHERE $COL_DAY_KEY IS NULL"
            )
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS $TABLE_LOG (
                    $LOG_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $LOG_TIME TEXT,
                    $LOG_ACTION TEXT,
                    $LOG_DETAILS TEXT
                )
                """.trimIndent()
            )
        }
    }

    // ------------------ تسجيل العمليات ------------------

    fun logOperation(action: String, details: String) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(LOG_TIME, DATETIME_FORMAT.format(Date()))
            put(LOG_ACTION, action)
            put(LOG_DETAILS, details)
        }
        db.insert(TABLE_LOG, null, values)
    }

    // ------------------ إضافة مواعيد ------------------

    fun insertAppointment(phone: String, name: String, message: String, status: String, createdAt: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_PHONE, phone)
            put(COL_NAME, name)
            put(COL_MESSAGE, message)
            put(COL_STATUS, status)
            put(COL_CREATED_AT, createdAt)
            put(COL_DAY_KEY, todayKey())
            put(COL_IS_MANUAL, 0)
        }
        val id = db.insert(TABLE_NAME, null, values)
        logOperation("تسجيل موعد جديد عبر رسالة", "$name / $phone / $status")
        return id
    }

    fun insertManualAppointment(phone: String, name: String, note: String): Long {
        val db = writableDatabase
        val createdAt = DATETIME_FORMAT.format(Date())
        val fullNote = "تم تسجيله يدوياً من قبل الطبيبة" + if (note.isNotBlank()) " — $note" else ""
        val values = ContentValues().apply {
            put(COL_PHONE, phone)
            put(COL_NAME, name)
            put(COL_MESSAGE, fullNote)
            put(COL_STATUS, STATUS_CONFIRMED)
            put(COL_CREATED_AT, createdAt)
            put(COL_DAY_KEY, todayKey())
            put(COL_IS_MANUAL, 1)
        }
        val id = db.insert(TABLE_NAME, null, values)
        logOperation("إضافة موعد يدوي", "$name / $phone")
        return id
    }

    fun insertScheduledAppointment(phone: String, name: String, appointmentDateTime: String): Long {
        val db = writableDatabase
        val createdAt = DATETIME_FORMAT.format(Date())
        val dayKey = appointmentDateTime.substring(0, minOf(10, appointmentDateTime.length))
        val values = ContentValues().apply {
            put(COL_PHONE, phone)
            put(COL_NAME, name)
            put(COL_MESSAGE, "موعد مبرمج مسبقاً")
            put(COL_STATUS, STATUS_CONFIRMED)
            put(COL_CREATED_AT, createdAt)
            put(COL_DAY_KEY, dayKey)
            put(COL_APPT_DATE, appointmentDateTime)
            put(COL_IS_MANUAL, 1)
        }
        val id = db.insert(TABLE_NAME, null, values)
        logOperation("برمجة موعد طبي", "$name / $phone / $appointmentDateTime")
        return id
    }

    // ------------------ تحقق من التكرار ------------------

    fun existsByPhoneOrName(phone: String, name: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, arrayOf(COL_ID),
            "$COL_PHONE = ? OR $COL_NAME = ?",
            arrayOf(phone, name),
            null, null, null
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    // ------------------ تحديث الحالة ------------------

    fun updateStatus(id: Long, status: String) {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_STATUS, status) }
        db.update(TABLE_NAME, values, "$COL_ID = ?", arrayOf(id.toString()))
        logOperation("تغيير حالة موعد", "رقم $id -> $status")
    }

    fun setNotifiedFlag(id: Long, column: String) {
        val db = writableDatabase
        val values = ContentValues().apply { put(column, 1) }
        db.update(TABLE_NAME, values, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun setThankYouSent(id: Long) = setNotifiedFlag(id, COL_THANK_YOU_SENT)

    // ------------------ الاستعلامات ------------------

    fun getTodayAppointments(): List<Appointment> = getAppointmentsForDay(todayKey())

    fun getAppointmentsForDay(dayKey: String): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null,
            "$COL_DAY_KEY = ?", arrayOf(dayKey),
            null, null, "$COL_ID DESC"
        )
        while (cursor.moveToNext()) list.add(cursorToAppointment(cursor))
        cursor.close()
        return list
    }

    data class DaySummary(val dayKey: String, val count: Int)

    fun getArchiveDays(): List<DaySummary> {
        val list = mutableListOf<DaySummary>()
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COL_DAY_KEY, COUNT(*) as cnt FROM $TABLE_NAME WHERE $COL_DAY_KEY != ? AND $COL_DAY_KEY IS NOT NULL GROUP BY $COL_DAY_KEY ORDER BY $COL_DAY_KEY DESC",
            arrayOf(todayKey())
        )
        while (cursor.moveToNext()) {
            list.add(DaySummary(cursor.getString(0), cursor.getInt(1)))
        }
        cursor.close()
        return list
    }

    fun searchByPatient(query: String): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val likeQuery = "%$query%"
        val cursor = db.query(
            TABLE_NAME, null,
            "$COL_NAME LIKE ? OR $COL_PHONE LIKE ?", arrayOf(likeQuery, likeQuery),
            null, null, "$COL_ID DESC"
        )
        while (cursor.moveToNext()) list.add(cursorToAppointment(cursor))
        cursor.close()
        return list
    }

    data class PatientRef(val phone: String, val name: String)

    fun getDistinctPatients(): List<PatientRef> {
        val list = mutableListOf<PatientRef>()
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT DISTINCT $COL_PHONE, $COL_NAME FROM $TABLE_NAME ORDER BY $COL_NAME ASC", null
        )
        while (cursor.moveToNext()) {
            list.add(PatientRef(cursor.getString(0), cursor.getString(1)))
        }
        cursor.close()
        return list
    }

    fun getConfirmedQueue(): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null,
            "$COL_STATUS = ? AND $COL_DAY_KEY = ?", arrayOf(STATUS_CONFIRMED, todayKey()),
            null, null, "$COL_ID ASC"
        )
        while (cursor.moveToNext()) list.add(cursorToAppointment(cursor))
        cursor.close()
        return list
    }

    fun countByStatusToday(status: String): Int {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, arrayOf(COL_ID),
            "$COL_STATUS = ? AND $COL_DAY_KEY = ?", arrayOf(status, todayKey()),
            null, null, null
        )
        val count = cursor.count
        cursor.close()
        return count
    }

    fun getAppointmentById(id: Long): Appointment? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null, "$COL_ID = ?", arrayOf(id.toString()),
            null, null, null
        )
        val result = if (cursor.moveToFirst()) cursorToAppointment(cursor) else null
        cursor.close()
        return result
    }

    fun getUpcomingScheduledAppointments(): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null,
            "$COL_APPT_DATE IS NOT NULL AND $COL_STATUS != ?", arrayOf(STATUS_FINISHED),
            null, null, "$COL_ID ASC"
        )
        while (cursor.moveToNext()) list.add(cursorToAppointment(cursor))
        cursor.close()
        return list
    }

    // ------------------ الحذف (يتطلب كلمة سر من واجهة المستخدم قبل الاستدعاء) ------------------

    fun deleteAll() {
        val db = writableDatabase
        db.delete(TABLE_NAME, null, null)
        logOperation("حذف كل المواعيد", "تم مسح الجدول بالكامل")
    }

    fun deleteAppointment(id: Long) {
        val db = writableDatabase
        db.delete(TABLE_NAME, "$COL_ID = ?", arrayOf(id.toString()))
        logOperation("حذف موعد نهائياً", "رقم $id")
    }

    private fun cursorToAppointment(cursor: Cursor): Appointment {
        fun colInt(name: String): Boolean {
            val idx = cursor.getColumnIndex(name)
            return idx >= 0 && cursor.getInt(idx) == 1
        }
        fun colStr(name: String): String? {
            val idx = cursor.getColumnIndex(name)
            return if (idx >= 0) cursor.getString(idx) else null
        }
        return Appointment(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
            phone = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE)),
            name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
            message = colStr(COL_MESSAGE) ?: "",
            status = cursor.getString(cursor.getColumnIndexOrThrow(COL_STATUS)),
            createdAt = colStr(COL_CREATED_AT) ?: "",
            dayKey = colStr(COL_DAY_KEY) ?: "",
            appointmentDate = colStr(COL_APPT_DATE),
            isManual = colInt(COL_IS_MANUAL),
            notified48 = colInt(COL_NOTIFIED_48),
            notified24 = colInt(COL_NOTIFIED_24),
            notifiedToday = colInt(COL_NOTIFIED_TODAY),
            thankYouSent = colInt(COL_THANK_YOU_SENT)
        )
    }
}
