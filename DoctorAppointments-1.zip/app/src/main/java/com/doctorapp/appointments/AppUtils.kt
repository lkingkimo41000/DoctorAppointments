package com.doctorapp.appointments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object AppUtils {

    /**
     * يفتح تطبيق الاتصال على رقم المريض قبل تأكيد الموعد (للتحقق من أنه سيحضر)
     */
    fun callPatient(context: Context, phone: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /**
     * يطلب كلمة سر الحذف المبرمجة داخل التطبيق قبل تنفيذ أي حذف نهائي للمواعيد
     */
    fun requestDeletePassword(context: Context, onConfirmed: () -> Unit) {
        val input = EditText(context).apply {
            hint = "كلمة سر الحذف"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(context)
            .setTitle("🔒 تأكيد الحذف النهائي")
            .setMessage("هذا الإجراء لا يمكن التراجع عنه. أدخلي كلمة سر الحذف للاستمرار.")
            .setView(input)
            .setPositiveButton("حذف") { _, _ ->
                if (Prefs.checkDeletePassword(context, input.text.toString().trim())) {
                    onConfirmed()
                } else {
                    Toast.makeText(context, "كلمة سر الحذف غير صحيحة", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
