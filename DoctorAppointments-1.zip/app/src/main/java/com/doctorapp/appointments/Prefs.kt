package com.doctorapp.appointments

import android.content.Context

/**
 * تخزين إعدادات التطبيق محلياً على هاتف الطبيبة:
 * - رقم هاتف الطبيبة الشخصي (يُبرمج مرة واحدة عند أول تشغيل)
 * - كلمة السر لفتح التطبيق (قابلة للتعديل من شاشة الإعدادات)
 * - كلمة سر حذف المواعيد (منفصلة عن كلمة سر الفتح، قابلة للتعديل)
 * - حالة استقبال المواعيد الجديدة (مفتوح / مغلق) — عند الإغلاق تُسجَّل
 *   الرسائل الواردة في قائمة "احتياط" مباشرة بدل قائمة الانتظار الرئيسية
 */
object Prefs {
    private const val PREFS_NAME = "doctor_app_prefs"

    private const val KEY_SETUP_DONE = "setup_done"
    private const val KEY_DOCTOR_PHONE = "doctor_phone"
    private const val KEY_PIN = "app_pin"
    private const val KEY_DELETE_PASSWORD = "delete_password"
    private const val KEY_REGISTRATION_OPEN = "registration_open"
    private const val KEY_DOCTOR_GENDER = "doctor_gender" // "male" أو "female"

    // --- نظام التفعيل عن بعد (الأكواد) ---
    private const val KEY_LICENSE_CODE = "license_code"
    private const val KEY_LICENSE_ACTIVE = "license_active"
    private const val KEY_LICENSE_EXPIRES_AT = "license_expires_at"
    private const val KEY_LICENSE_LAST_SYNC = "license_last_sync"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ============ التفعيل ============

    fun getLicenseCode(context: Context): String =
        prefs(context).getString(KEY_LICENSE_CODE, "") ?: ""

    fun getLicenseExpiresAt(context: Context): Long =
        prefs(context).getLong(KEY_LICENSE_EXPIRES_AT, 0L)

    fun getLicenseLastSync(context: Context): Long =
        prefs(context).getLong(KEY_LICENSE_LAST_SYNC, 0L)

    fun isLicenseActiveFlag(context: Context): Boolean =
        prefs(context).getBoolean(KEY_LICENSE_ACTIVE, false)

    fun saveLicenseState(context: Context, code: String, active: Boolean, expiresAt: Long, syncedAt: Long) {
        prefs(context).edit()
            .putString(KEY_LICENSE_CODE, code)
            .putBoolean(KEY_LICENSE_ACTIVE, active)
            .putLong(KEY_LICENSE_EXPIRES_AT, expiresAt)
            .putLong(KEY_LICENSE_LAST_SYNC, syncedAt)
            .apply()
    }

    fun clearLicense(context: Context) {
        prefs(context).edit()
            .remove(KEY_LICENSE_CODE)
            .remove(KEY_LICENSE_ACTIVE)
            .remove(KEY_LICENSE_EXPIRES_AT)
            .remove(KEY_LICENSE_LAST_SYNC)
            .apply()
    }

    /**
     * عدد الأيام المتبقية على انتهاء كود التفعيل (0 أو أكثر).
     * نستخدم التقريب لأعلى بالأيام الكاملة حتى يظهر "1 يوم" في آخر يوم من الصلاحية
     * بدل أن يظهر صفراً بينما التطبيق لا يزال يعمل لبقية ذلك اليوم.
     */
    fun getLicenseRemainingDays(context: Context): Int {
        val expiresAt = getLicenseExpiresAt(context)
        if (expiresAt <= 0L) return 0
        val diffMs = expiresAt - System.currentTimeMillis()
        if (diffMs <= 0) return 0
        val oneDayMs = 24L * 60 * 60 * 1000
        return ((diffMs + oneDayMs - 1) / oneDayMs).toInt()
    }

    fun isSetupDone(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SETUP_DONE, false)

    fun completeSetup(context: Context, doctorPhone: String, pin: String, deletePassword: String, doctorGender: String) {
        prefs(context).edit()
            .putBoolean(KEY_SETUP_DONE, true)
            .putString(KEY_DOCTOR_PHONE, doctorPhone)
            .putString(KEY_PIN, pin)
            .putString(KEY_DELETE_PASSWORD, deletePassword)
            .putBoolean(KEY_REGISTRATION_OPEN, true)
            .putString(KEY_DOCTOR_GENDER, doctorGender)
            .apply()
    }

    fun getDoctorPhone(context: Context): String =
        prefs(context).getString(KEY_DOCTOR_PHONE, "") ?: ""

    fun setDoctorPhone(context: Context, phone: String) {
        prefs(context).edit().putString(KEY_DOCTOR_PHONE, phone).apply()
    }

    fun getPin(context: Context): String =
        prefs(context).getString(KEY_PIN, "0000") ?: "0000"

    fun setPin(context: Context, pin: String) {
        prefs(context).edit().putString(KEY_PIN, pin).apply()
    }

    fun checkPin(context: Context, input: String): Boolean = getPin(context) == input

    fun getDeletePassword(context: Context): String =
        prefs(context).getString(KEY_DELETE_PASSWORD, "1234") ?: "1234"

    fun setDeletePassword(context: Context, password: String) {
        prefs(context).edit().putString(KEY_DELETE_PASSWORD, password).apply()
    }

    fun checkDeletePassword(context: Context, input: String): Boolean =
        getDeletePassword(context) == input

    fun isRegistrationOpen(context: Context): Boolean =
        prefs(context).getBoolean(KEY_REGISTRATION_OPEN, true)

    fun setRegistrationOpen(context: Context, open: Boolean) {
        prefs(context).edit().putBoolean(KEY_REGISTRATION_OPEN, open).apply()
    }

    // ============ لقب الطبيب/ة (لضبط صيغة الخطاب في كل التطبيق) ============

    fun setDoctorGender(context: Context, gender: String) {
        prefs(context).edit().putString(KEY_DOCTOR_GENDER, gender).apply()
    }

    fun getDoctorGender(context: Context): String =
        prefs(context).getString(KEY_DOCTOR_GENDER, "female") ?: "female"

    /** يُستخدم في كل نصوص الواجهة والرسائل: "الطبيب" أو "الطبيبة" حسب اختيار المستخدم */
    fun getDoctorTitle(context: Context): String =
        if (getDoctorGender(context) == "male") "الطبيب" else "الطبيبة"
}
