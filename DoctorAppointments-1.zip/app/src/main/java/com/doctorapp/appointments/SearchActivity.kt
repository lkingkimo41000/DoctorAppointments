package com.doctorapp.appointments

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class SearchActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: AppointmentAdapter
    private lateinit var etQuery: EditText
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        db = DatabaseHelper(this)

        etQuery = findViewById(R.id.etSearchQuery)
        tvEmpty = findViewById(R.id.tvSearchEmpty)
        val recycler = findViewById<RecyclerView>(R.id.recyclerSearchResults)
        recycler.layoutManager = LinearLayoutManager(this)

        adapter = AppointmentAdapter(
            items = emptyList(),
            onDeleteRequest = { appointment ->
                AppUtils.requestDeletePassword(this) {
                    db.deleteAppointment(appointment.id)
                    runSearch()
                }
            },
            onCall = { AppUtils.callPatient(this, it.phone) },
            onAccept = {}, onMoveFromReserve = {}, onAbsent = {},
            onEnterDoctor = {}, onFinish = {}, onRestore = {},
            readOnly = true
        )
        recycler.adapter = adapter

        findViewById<MaterialButton>(R.id.btnSearch).setOnClickListener { runSearch() }
    }

    private fun runSearch() {
        val query = etQuery.text.toString().trim()
        if (query.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال اسم أو رقم هاتف للبحث", Toast.LENGTH_SHORT).show()
            return
        }
        val results = db.searchByPatient(query)
        adapter.updateData(results)
        tvEmpty.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
        tvEmpty.text = if (results.isEmpty()) "لا توجد نتائج مطابقة" else ""
    }
}
