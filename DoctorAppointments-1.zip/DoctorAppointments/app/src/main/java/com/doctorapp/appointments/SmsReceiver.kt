package com.doctorapp.appointments

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

/**
 * يستقبل كل رسالة SMS واردة على هاتف الطبيب.
 * - يستخرج اسم ولقب المريض من نص الرسالة
 * - يسجّل الموعد أوتوماتيكياً في قاعدة البيانات
 * - يرد على المريض برسالة "مقبول" من نفس رقم الهاتف الحقيقي
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isEmpty()) return

        // بعض الرسائل الطويلة تصل مجزأة على أكثر من segment، لهذا نجمعها
        val senderPhone = messages[0].originatingAddress ?: return
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }.trim()

        if (fullBody.isEmpty()) return

        val patientName = extractPatientName(fullBody)
        if (patientName == null) {
            Log.w("SmsReceiver", "لم يتم التعرف على اسم صالح في الرسالة: $fullBody")
            return
        }

        // 1) تسجيل الموعد في قاعدة البيانات
        val db = DatabaseHelper(context)
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        db.insertAppointment(
            phone = senderPhone,
            name = patientName,
            message = fullBody,
            status = "مؤكد",
            createdAt = timestamp
        )

        // 2) إرسال رد تلقائي "مقبول" لنفس رقم المريض
        sendAutoReply(senderPhone, patientName)
    }

    /**
     * منطق استخراج الاسم من نص الرسالة.
     * حاليًا: يعتبر نص الرسالة كاملاً هو "الاسم واللقب" إذا كان يحتوي على كلمتين على الأقل
     * (يمكن تعديل هذا المنطق حسب الصيغة التي يطلبها المرضى إرسالها فعليًا،
     * مثلاً "حجز: أحمد بلعيد" أو مجرد "أحمد بلعيد")
     */
    private fun extractPatientName(body: String): String? {
        // تنظيف الرسالة من كلمات مفتاحية شائعة إن وجدت
        val cleaned = body
            .replace("حجز", "", ignoreCase = true)
            .replace("موعد", "", ignoreCase = true)
            .replace(":", "")
            .trim()

        val words = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }

        // يجب أن يحتوي على الأقل اسم ولقب (كلمتين)، وألا يكون أرقاماً فقط
        if (words.size < 2) return null
        if (cleaned.any { it.isDigit() }) return null

        return cleaned
    }

    private fun sendAutoReply(phoneNumber: String, patientName: String) {
        try {
            val smsManager = SmsManager.getDefault()
            val replyText = "مرحباً $patientName، تم تسجيل موعدك بنجاح. الحالة: مقبول ✅"

            // تقسيم الرسالة الطويلة تلقائياً إذا تجاوزت الحد المسموح
            val parts = smsManager.divideMessage(replyText)
            smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)

            Log.i("SmsReceiver", "تم إرسال رد القبول إلى: $phoneNumber")
        } catch (e: Exception) {
            Log.e("SmsReceiver", "فشل إرسال الرد التلقائي", e)
        }
    }
}
