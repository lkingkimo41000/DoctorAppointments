package com.doctorapp.appointments

data class Appointment(
    val id: Long = 0,
    val phone: String,       // رقم المريض الحقيقي
    val name: String,        // اسم ولقب المريض المستخرج من الرسالة
    val message: String,     // نص الرسالة الأصلي
    val status: String,      // "مؤكد" أو "قيد الانتظار" أو "مرفوض"
    val createdAt: String    // تاريخ ووقت الاستقبال
)
