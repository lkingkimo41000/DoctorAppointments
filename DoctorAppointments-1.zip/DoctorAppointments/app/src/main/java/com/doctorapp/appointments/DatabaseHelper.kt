package com.doctorapp.appointments

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "appointments.db"
        private const val DB_VERSION = 1
        const val TABLE_NAME = "appointments"

        const val COL_ID = "id"
        const val COL_PHONE = "phone"
        const val COL_NAME = "name"
        const val COL_MESSAGE = "message"
        const val COL_STATUS = "status"
        const val COL_CREATED_AT = "created_at"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_PHONE TEXT NOT NULL,
                $COL_NAME TEXT NOT NULL,
                $COL_MESSAGE TEXT,
                $COL_STATUS TEXT DEFAULT 'مؤكد',
                $COL_CREATED_AT TEXT
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // إضافة موعد جديد، يرجع الـ id الجديد
    fun insertAppointment(phone: String, name: String, message: String, status: String, createdAt: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_PHONE, phone)
            put(COL_NAME, name)
            put(COL_MESSAGE, message)
            put(COL_STATUS, status)
            put(COL_CREATED_AT, createdAt)
        }
        val id = db.insert(TABLE_NAME, null, values)
        db.close()
        return id
    }

    // جلب كل المواعيد مرتبة من الأحدث للأقدم
    fun getAllAppointments(): List<Appointment> {
        val list = mutableListOf<Appointment>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME, null, null, null, null, null,
            "$COL_ID DESC"
        )
        while (cursor.moveToNext()) {
            list.add(
                Appointment(
                    id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
                    phone = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
                    message = cursor.getString(cursor.getColumnIndexOrThrow(COL_MESSAGE)),
                    status = cursor.getString(cursor.getColumnIndexOrThrow(COL_STATUS)),
                    createdAt = cursor.getString(cursor.getColumnIndexOrThrow(COL_CREATED_AT))
                )
            )
        }
        cursor.close()
        db.close()
        return list
    }

    fun deleteAll() {
        val db = writableDatabase
        db.delete(TABLE_NAME, null, null)
        db.close()
    }

    fun deleteAppointment(id: Long) {
        val db = writableDatabase
        db.delete(TABLE_NAME, "$COL_ID = ?", arrayOf(id.toString()))
        db.close()
    }
}
