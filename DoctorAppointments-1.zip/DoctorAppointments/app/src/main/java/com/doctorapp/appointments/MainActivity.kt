package com.doctorapp.appointments

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: AppointmentAdapter
    private lateinit var countText: TextView

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.SEND_SMS
    )
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)
        countText = findViewById(R.id.tvCount)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AppointmentAdapter(emptyList()) { appointment ->
            db.deleteAppointment(appointment.id)
            refreshList()
        }
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refreshList() }
        findViewById<Button>(R.id.btnClearAll).setOnClickListener {
            db.deleteAll()
            refreshList()
            Toast.makeText(this, "تم مسح كل المواعيد", Toast.LENGTH_SHORT).show()
        }

        checkAndRequestPermissions()
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val appointments = db.getAllAppointments()
        adapter.updateData(appointments)
        countText.text = "عدد المواعيد: ${appointments.size}"
    }

    private fun checkAndRequestPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (!allGranted) {
                Toast.makeText(
                    this,
                    "يجب منح صلاحيات الرسائل ليعمل التطبيق بشكل صحيح",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
